# Additional AC112 controls — 1.6.6

Fan and vertical-swing tables are enabled for all 70 hash-pinned experimental source definitions. Timer mappings are available on 56 definitions; at least one special function is available on 56. The remaining 14 in each category report unavailable controls. These are profile-specific capabilities, not proof that every appliance of the 45 brand labels responds.

The additional encoder tests compare 14,832 independently generated source-table packet fixtures across both transports (29,664 Java waveforms). The pinned public TCL encoder independently matches 7,120 fan/swing combinations. The original 4,200 basic packets and 8,400 waveforms remain checked. Source timers and special-function fields can differ from public TCL semantics, so their evidence is reviewed source mapping plus packet/checksum/transport validation, not public timer or auxiliary-function equivalence. No source hook is executed. Timer requests are removed from persisted state so ordinary sends cannot automatically repeat them. Saved fan, swing and special settings round-trip and copied states remain independent.

Current build and validation results are in downloads/validation.json. Physical responses and emulator UI execution are not claimed. The expanded instrumentation checks compile but require a device for execution. Notes below apply to their stated earlier versions.

# Expanded AC112 encoder validation — 1.6.5

133 JVM tests cover the current app. Seventy explicitly reviewed, source-hash-pinned definitions add 140 experimental candidates (two timing variants each). All 4,200 core power/mode/temperature packets match both pinned public reference encoders; 8,400 Java-generated waveforms pass strict upstream decoding with exact payload checks. Supported controls are power, Cool/Heat and 16–30 °C; fan, swing and timers are unavailable on these new candidates. Packet proof does not establish hardware compatibility or exact Mi engine equivalence.

All 64 AC brand labels have candidates to try: 101 recorded remotes, six original Panasonic parameter candidates, four original experimental candidates and 140 new timing-variant candidates, 251 total. Seventy of the requested 694 definitions are now experimental candidates; 624 remain unsupported. The earlier setup-only notes below describe the intermediate implementation before these encoders were added.

# Palm Remote 1.6.5 AC setup update

All 64 AC brand labels have the guided-testing entry. Inventory tests distinguish 41 brands with 111 sendable candidates from 23 without an implemented encoder. The 111 candidates comprise 101 recorded remotes, six Panasonic parameter candidates and four experimental protocol candidates. Tests load or encode each offered candidate, check per-brand routing, and exclude all 694 source definitions that still lack controls. No new encoder, physical AC response or emulator UI result is claimed. The compiled UI checks include available and unavailable AC brands. Coverage and unverified protocol grouping reports are reproducible from the bundled source. See downloads/validation.json for completed build checks.

# Palm Remote 1.6.4 fan update

All 133 fan brands offer guided testing first, covering 422 candidates and 4,181 command associations. Production-loader tests verify all fan candidates and the six single-button limitations. The shared response state requires two distinct confirmations by default, or only the available button for an explicitly limited fan candidate, and resets fully between candidates. Fan, decoder and TV coverage CSVs are checked from the bundled indexes. Compiled UI checks include six representative fan brands; physical responses and emulator UI results remain unverified. See downloads/validation.json for completed build checks.

# Palm Remote 1.6.3 decoder update

All 182 decoder brands now offer guided testing first. Production-loader tests cover all 411 decoder candidates and 12,416 command associations, preserving the five Astro candidates. Each candidate has at least two recorded buttons. Decoder and TV setup share the two-button response confirmation gate. Decoder and TV coverage CSV checks pass. The decoder UI test source includes six representative brands, and the existing eighteen-brand TV checks remain. Physical responses and emulator UI results are unverified for this update. See downloads/validation.json for completed build checks.

# Palm Remote 1.6.2 TV update

The current update passes 126 JVM tests, lint (zero errors), app assembly and instrumentation APK assembly. Every selectable TV brand now opens the same first guided-testing option. Tests load all 3,381 candidates across all 1,020 selectable brands and verify at least two recorded buttons per candidate. The coverage CSV is regenerated and checked from the bundled indexes. All packaged assets match their source bytes.

Physical TV responses and emulator UI tests have not been verified for 1.6.2; no KVM acceleration is available in this environment. The instrumentation source includes eighteen representative TV brands for later device checks. Earlier release evidence below applies to its stated version.

# Palm Remote validation

## Version 1.6.0 — 25 October 2026

The final development-signed APK passed an in-place emulator install and its installed bytes match `downloads/SHA256SUMS`. All 123 JVM tests, Android lint (zero errors), 35 Android catalogue/hardware checks and 21 UI checks passed. The UI checks cover every new candidate's source identity, experimental label, preview save and absent-emitter transmission gates. Test preferences were restored. The Android 29 x86_64 emulator has no IR emitter; no physical AC response was tested.

All 960 exposed setting combinations produce packets identical to the pinned IRremoteESP8266 reference encoders; all 960 Java-generated waveforms also pass the reference's strict decoders. The tracked 7z was re-extracted and all 734 source assets regenerated byte for byte. No vendor hooks or native libraries were executed.

Four experimental protocol candidates are added alongside the 36 existing source-mapped AC controls. Exact equivalence to Mi's engine remains unverified. The other 694 AC source records still have no controls. See [scope and reproduction](AC_PROTOCOL_CANDIDATES.md), [build metadata](../downloads/build-info.json), [Android results](../downloads/catalog-validation.txt), [UI evidence](../downloads/emulator-verification.json) and [screenshots](screenshots/v1.6/).

## Historical 1.5.0 validation

Validated on 21 October 2026. This release adds complete source data for **all 734 AC records / 45 brand labels** in the supplied Mi Remote **7.2.4M / code 6500** APK. There are zero source records omitted. This is complete bundled AC data inclusion, not 734 implemented encoders or coverage of online-only Mi profiles.

## Complete source preservation

The offline exporter verifies the pinned 7z, APK, nested RAR and SQLite hashes before reading. Each generated JSON retains every original model-row value, its full referenced source row, complete decoded definition, original brand row and decoded brand data. Original encrypted strings and hook text are preserved. Six new Python checks compare every source/reference/definition/brand record against the archive, verify source/output hashes, check deterministic output and reject missing, extra or changed assets. Default archive extraction and byte-for-byte regeneration passed.

| Source AC data | Included | Existing controls |
| --- | ---: | ---: |
| Recorded profiles | 33 | 33 |
| Stateful definitions | 701 | 3 Panasonic216 |
| Total | **734** | **36** |

The remaining **698 profiles are stored as data with controls unavailable**. Their vendor parameter/hook text is never executed or compiled. No vendor Lua runtime, native AC engine or decompiled Java implementation is included. Three additional GitHub Panasonic parameter profiles remain outside this 734-source count. No data-only record is counted as a working remote.

## Software checks

`./gradlew --no-daemon testDebugUnitTest lintDebug assembleDebug assembleDebugAndroidTest` completed **BUILD SUCCESSFUL**. All **120 JVM tests** passed with zero failures, errors or skips. Lint reports **0 errors / 15 SetTextI18n warnings**.

All **74 Python tests** passed: original catalogue 10, Astro 7, APK research 29, raw APK conversion 8, TV matching 8, Panasonic parameters 6 and complete AC source export 6. The eight new JVM tests load all 734 packaged source assets, verify all 36 links to exact existing controls, preserve script text as data and reject incorrect source identity, incomplete coverage, false support claims, changed bytes, path traversal, mismatched source references and oversized input.

Existing TV, Astro, fan, raw AC and Panasonic encoder tests still pass. Original raw source IDs, carriers, timings and matching order are unchanged. Existing credential migration and Panasonic persistence checks remain.

## Installed Android checks

The delivered APK installed as an in-place update on the retained Android 10 / API 29 x86_64 software emulator. All **35 Android checks** and **17 UI checks** passed. Every one of the 734 source records was loaded and validated; the new searchable inventory, complete source-data view and exact recorded/Panasonic control links passed with absent-emitter gates intact. Data-only profiles exposed no working-control action. Source browsing and opening controls did not save a device or send IR. Exact original preferences were restored, and the pulled installed APK matched the delivered SHA-256.

See [installed verification](../downloads/emulator-verification.json), [instrumentation output](../downloads/catalog-validation.txt) and [screenshots](screenshots/v1.5/). An earlier run was interrupted by an environment restart. A cold run also exposed an accepted accessibility Done action that left a native dialog open; the test harness now waits for startup loading to settle, sends one accessibility action per target without a touch fallback, and verifies native Done/Close dismissal. This correction changed only the test harness. A subsequent check exposed AC catalogue work delaying recorded signals; AC data loading and viewing now use a separate worker, and repeated validation patterns are cached. Existing remotes load independently. The completed run is recorded here. The final run recorded 0 bounded System UI dialog recoveries. This host has no KVM; the harness does not ignore a Palm Remote nonresponse. Emulator checks do not establish physical appliance response.

## Artifact

- APK: [PalmRemote.apk](../downloads/PalmRemote.apk); package `com.universalremote.app`
- Version **1.5.0**, versionCode **8**; minimum API 23, target API 35
- Size **13,770,317 bytes**
- SHA-256 `dbabb53cb66b24d17cddd3370cb4ef94f3236cfa7604c650bff7f1fca9b9c9a8`
- v1/v2 signature verified; same development certificate SHA-256 `75e8320e3978d0cc65f0fb98c0bb82354a05dd02e1c34d96823d883cab9e4e64` for in-place updates
- ZIP 16-KiB alignment passed; all **5,060 packaged assets** matched workspace files byte for byte, including all 734 complete AC record assets
- Java-only app; no native libraries included

The raw control catalogue remains **4,315 profiles / 165,369 recorded command associations**, plus six adjustable Panasonic profiles. The full AC source-data browser is a separate count. The user reported working Astro Ultra Box control in Palm 1.3.0; those signals remain unchanged. Full AC data inclusion does not imply that the user's AC has been physically tested or that unsupported stateful definitions can transmit. See [complete AC scope](COMPLETE_AC_DATABASE.md), [source exporter](../tools/mi_ac_database/README.md) and [known limitations](KNOWN_LIMITATIONS.md).
