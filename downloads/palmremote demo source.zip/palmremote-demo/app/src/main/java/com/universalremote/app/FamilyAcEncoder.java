package com.universalremote.app;
import org.json.JSONObject;
import java.util.*;
/** Demo contains only the source-pinned Panasonic/Midea experimental candidates. */
final class FamilyAcEncoder {
    static final String[] MODELS={};
    private final Map<String,JSONObject> profiles=new LinkedHashMap<>();
    FamilyAcEncoder(AcSourceDatabase source) throws Exception {
        for(JSONObject p:ExpandedAcEncoder.profiles(source))profiles.put(p.getString("id").substring(7),p);
    }
    static int family(String model){return -1;}
    static boolean supports(String model){return ExpandedAcEncoder.supports(model);}
    JSONObject find(String id){return profiles.get(id.startsWith("family_")?id.substring(7):id);}
    List<JSONObject> profiles(){return new ArrayList<>(profiles.values());}
    static PanasonicAcEncoder.Signal encode(JSONObject profile,PanasonicAcEncoder.State state,boolean powerPress) throws Exception {
        if(!profile.optBoolean("expanded"))throw new IllegalArgumentException("Candidate excluded from demo.");
        return ExpandedAcEncoder.encode(profile,state);
    }
}
