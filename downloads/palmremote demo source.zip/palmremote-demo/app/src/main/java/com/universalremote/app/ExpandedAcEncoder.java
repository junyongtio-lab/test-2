package com.universalremote.app;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Source-pinned 112-bit protocol candidates. Basic state plus bounded, source-mapped additional controls. */
final class ExpandedAcEncoder {
    private static final Map<String,String> APPROVED=new LinkedHashMap<>();
    static {
        // BEGIN APPROVED SOURCES
        approve("110_2807","7d3ba7843b07600416b77dc65932c4cd0eb1438c8f4b8731bf6103f1eb576eee");
        approve("137_2807","b3dd6e8d9b37dc3278798a431d81efa64e75d3985aaff49b327a73935672da7e");
        // END APPROVED SOURCES
    }
    private static void approve(String model,String asset){APPROVED.put(model,asset);}
    static boolean supports(String model){return APPROVED.containsKey(model);}
    static List<JSONObject> profiles(AcSourceDatabase source) throws Exception {
        List<JSONObject> result=new ArrayList<>();
        for(JSONObject metadata:source.profiles(null)) {
            String model=metadata.getString("model");if(!supports(model))continue;
            if(!APPROVED.get(model).equals(metadata.getString("assetSha256")))throw new IllegalArgumentException("AC112 source asset changed.");
            JSONObject definition=source.readRecord(metadata.getString("id")).getJSONObject("definition");
            for(int variant=0;variant<2;variant++) {
                JSONObject p=new JSONObject(metadata.toString());
                p.put("id","family_"+model+(variant==0?"":"_tcl112")).put("family",variant==0?"AC112_TIMING_A":"AC112_TIMING_B")
                    .put("expanded",true).put("variant",variant).put("carrierHz",38000).put("sourceCarrierHz",metadata.getInt("carrierHz"))
                    .put("definition",definition).put("definitionDigest",IrCatalog.sha256(definition.toString()))
                    .put("powerToggle",false).put("supportsFan",true).put("supportsSwing",true).put("additionalControls",Ac112Controls.describe(definition))
                    .put("modes",new JSONArray().put("cool").put("heat"));
                result.add(p);
            }
        }
        if(result.size()!=APPROVED.size()*2)throw new IllegalArgumentException("AC112 candidate sources are missing.");
        return result;
    }
    static PanasonicAcEncoder.Signal encode(JSONObject p,PanasonicAcEncoder.State state) throws Exception {
        String model=p.getString("model");
        if(!supports(model)||!APPROVED.get(model).equals(p.getString("assetSha256"))||state==null||state.mode==null
            ||!(state.mode.equals("cool")||state.mode.equals("heat"))||state.temperature<16||state.temperature>30)
            throw new IllegalArgumentException("Unsupported AC112 candidate or requested control.");
        JSONObject d=p.getJSONObject("definition");
        if(!IrCatalog.sha256(d.toString()).equals(p.getString("definitionDigest")))throw new IllegalArgumentException("AC112 definition changed.");
        byte[] source=PanasonicAcEncoder.hex(d.getString("1002"));
        if(source.length!=15||source[0]!=14||source[1]!=0x23||(source[2]&255)!=0xcb||source[3]!=0x26||source[4]!=1)
            throw new IllegalArgumentException("Unsupported AC112 packet.");
        byte[] packet=java.util.Arrays.copyOfRange(source,1,15);
        packet[5]=(byte)((packet[5]&~4)|(state.power?4:0));
        packet[6]=(byte)((packet[6]&0xf0)|(state.mode.equals("heat")?1:3));
        packet[7]=(byte)((packet[7]&0xf0)|(31-state.temperature));
        packet[12]=(byte)(packet[12]&~0x20);
        Ac112Controls.apply(d,state,packet);
        int sum=0;for(int i=0;i<13;i++)sum+=packet[i]&255;packet[13]=(byte)sum;
        int variant=p.getInt("variant");
        String family=p.getString("family");
        if(variant<0||variant>1||!family.equals(variant==0?"AC112_TIMING_A":"AC112_TIMING_B")||p.getInt("carrierHz")!=38000)
            throw new IllegalArgumentException("Unsupported AC112 transport.");
        int mark=variant==0?450:500,zero=variant==0?385:325,one=variant==0?1250:1050;
        int[] pattern=new int[228];int at=0;
        pattern[at++]=variant==0?3450:3000;pattern[at++]=variant==0?1696:1650;
        for(byte b:packet)for(int bit=0;bit<8;bit++){pattern[at++]=mark;pattern[at++]=((b>>>bit)&1)==0?zero:one;}
        pattern[at++]=mark;pattern[at]=100000;
        IrCatalog.validateSignal(38000,pattern);
        return new PanasonicAcEncoder.Signal(38000,pattern,packet);
    }
}
