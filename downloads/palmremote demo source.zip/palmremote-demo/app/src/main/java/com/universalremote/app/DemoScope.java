package com.universalremote.app;
/** Crowdfunding demo brand/category allowlist. */
final class DemoScope {
    static boolean allowed(String category,String brand){
        if(category==null||brand==null)return false;
        switch(category){
            case "tv":return brand.equalsIgnoreCase("Samsung");
            case "air_conditioner":return brand.equalsIgnoreCase("Panasonic")||brand.equalsIgnoreCase("Midea");
            case "fan":return brand.equalsIgnoreCase("KDK")||brand.equalsIgnoreCase("Panasonic");
            case "set_top_box":return brand.equalsIgnoreCase("Astro");
            default:return false;
        }
    }
}
