package com.universalremote.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.widget.*;
import com.universalremote.app.protocols.*;
import com.universalremote.app.smartthings.SmartThingsClient;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.*;
import java.util.concurrent.*;

/** Account-free, local-first controller. A command is successful only after the transport accepts it. */
public final class MainActivity extends Activity {
    private static final int BG=0xff10141f, CARD=0xff1a2130, EDGE=0xff2c3548,
        TEXT=0xfff5f7fc, MUTED=0xffa8b3c8, MINT=0xff91e5d0, LILAC=0xffbcb3ff;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final ExecutorService hardwareWorker = Executors.newSingleThreadExecutor();
    private final ExecutorService acSourceWorker = Executors.newSingleThreadExecutor();
    private IrHardware.Result irHardware = IrHardware.checking();
    private DeviceStore store;
    private IrCatalog infrared;
    private PanasonicAcEncoder panasonic;
    private AcSourceDatabase acSourceDatabase;
    private FamilyAcEncoder familyAc;
    private boolean acSourceFailed;
    private final List<JSONObject> devices = new ArrayList<>();
    private JSONObject selected;
    private NetworkRemote network;
    private SmartThingsClient cloud;
    private SmartThingsClient.Device cloudDevice;
    private LinearLayout root, content, nav;
    private TextView statusText;
    private TextView irHardwareTitle, irHardwareDetail;
    private Button irHardwareButton;
    private String currentPage="Home", status="Choose a device to get started", notice="", irProfileError="";
    private boolean connected, busy, hardwareChecking, irCatalogFailed, panasonicFailed;
    private volatile boolean destroyed;
    private volatile long connectionGeneration;
    private long renderedControlsGeneration;
    private final Map<View,String> commandButtons = new HashMap<>();
    private final List<View> panasonicSendButtons = new ArrayList<>();
    private final List<View> panasonicEditors = new ArrayList<>();
    private PanasonicAcEncoder.State panasonicDraft;
    private String panasonicDraftDeviceId="";
    private final int[] acTimerMinutes={60,60};

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        store = new DeviceStore(this);
        devices.addAll(store.load());
        if (!devices.isEmpty()) selected=devices.get(0);
        render();
        // Keep asset parsing off the first-frame path, including on slower Android phones.
        worker.execute(()->{
            try {
                IrCatalog loaded=new IrCatalog(this);
                ui(()->{
                    infrared=loaded;
                    try {
                        String selectedId=selected==null?"":selected.optString("id");
                        int removed=store.removeUnavailableIrDevices(loaded);
                        if(removed>0) {
                            devices.clear();devices.addAll(store.load());selected=null;
                            for(JSONObject device:devices)if(device.optString("id").equals(selectedId))selected=device;
                            if(selected==null&&!devices.isEmpty())selected=devices.get(0);
                            notice=removed+" previous IR remote(s) removed. Add a matching remote from the Mi Remote catalogue. Wi-Fi devices and credentials were retained.";
                        }
                    }catch(Exception error){notice="Could not update saved IR remotes: "+error.getMessage();}
                    render();if(selected!=null)connect();
                });
            } catch(Exception error) {
                ui(()->{irCatalogFailed=true;notice="IR profiles could not load: "+error.getMessage();render();if(selected!=null)connect();});
            }
        });
        // AC parameter loading is independent: a bad AC asset must not disable working Astro/TV remotes.
        worker.execute(()->{
            try {
                PanasonicAcEncoder loaded=new PanasonicAcEncoder(this);
                ui(()->{panasonic=loaded;if(selectedUsesStatefulAc())connect();render();});
            } catch(Exception error) {
                ui(()->{panasonicFailed=true;if(selectedUsesStatefulAc()){updateIrRemoteAvailability();render();}});
            }
        });
        acSourceWorker.execute(()->{
            try {
                AcSourceDatabase loaded=new AcSourceDatabase(this);
                FamilyAcEncoder families=new FamilyAcEncoder(loaded);
                ui(()->{acSourceDatabase=loaded;familyAc=families;if(selectedUsesStatefulAc())connect();render();});
            }catch(Exception error){ui(()->{acSourceFailed=true;render();});}
        });
    }
    @Override protected void onResume() {
        super.onResume();
        checkIrHardware(false);
    }
    private void checkIrHardware(boolean showDetails) {
        if(hardwareChecking||destroyed)return;
        hardwareChecking=true;irHardware=IrHardware.checking();updateIrHardwareViews();updateIrRemoteAvailability();
        // A separate worker keeps phone detection independent of catalogue loading and TV pairing.
        hardwareWorker.execute(()->{
            IrHardware.Result result=IrHardware.inspect(getApplicationContext());
            ui(()->{
                hardwareChecking=false;irHardware=result;updateIrHardwareViews();updateIrRemoteAvailability();
                if(showDetails)showIrHardwareDetails();
            });
        });
    }
    private void updateIrHardwareViews() {
        if(irHardwareTitle==null)return;
        irHardwareTitle.setText(irHardware.title);
        irHardwareTitle.setTextColor(irHardware.hasEmitter?MINT:TEXT);
        irHardwareDetail.setText(irHardware.detail);
        irHardwareButton.setEnabled(!hardwareChecking);
        irHardwareButton.setText(hardwareChecking?"Checking…":"Check IR");
    }
    private void showIrHardwareDetails() {
        String version="";
        try{version=getPackageManager().getPackageInfo(getPackageName(),0).versionName;}catch(Exception ignored){/* Optional display metadata. */}
        String details="Palm Remote "+version+"\nPhone: "+android.os.Build.MANUFACTURER+" "+android.os.Build.MODEL
            +"\nAndroid: "+android.os.Build.VERSION.RELEASE+"\n\n"+irHardware.diagnostics
            +"\n\nThis checks the phone's built-in IR hardware. It does not test whether your TV, decoder or air conditioner responds. USB accessories and external IR hubs are not supported by this APK.";
        if(selected!=null)details+="\n\nSelected remote: "+selected.optString("name")
            +"\nSource keyset: "+selected.optString("sourceModelId",selected.optString("profile"));
        new AlertDialog.Builder(this).setTitle(irHardware.title).setMessage(details)
            .setPositiveButton("Done",null).setNeutralButton("Check again",(dialog,which)->checkIrHardware(true)).show();
    }
    private boolean selectedUsesIr() {
        return selected!=null&&selected.optString("mode").equals("ir");
    }
    private boolean selectedUsesStatefulAc() {
        return selected!=null&&(selected.optString("mode").equals("panasonic_ac")||selected.optString("mode").equals("family_ac"));
    }
    private JSONObject currentAcProfile() {
        if(selected==null)return null;
        String id=selected.optString("profile");
        return selected.optString("mode").equals("family_ac")?(familyAc==null?null:familyAc.find(id)):(panasonic==null?null:panasonic.find(id));
    }
    private static PanasonicAcEncoder.Signal encodeAc(JSONObject profile,PanasonicAcEncoder.State state,boolean powerPress) throws Exception {
        return profile.has("family")?FamilyAcEncoder.encode(profile,state,powerPress):PanasonicAcEncoder.encode(profile,state,powerPress);
    }
    private void updateIrRemoteAvailability() {
        if(selectedUsesStatefulAc()) {
            boolean family=selected.optString("mode").equals("family_ac");
            boolean loaded=family?familyAc!=null:panasonic!=null;
            if(!loaded)updateStatus((family?acSourceFailed:panasonicFailed)?"AC definitions could not load.":"AC definitions are loading…",false);
            else if(currentAcProfile()==null)updateStatus("This AC profile is unavailable. Choose a matching AC remote again.",false);
            else if(infrared==null)updateStatus(irCatalogFailed?"The infrared catalogue could not load. Restart the app to retry.":"The infrared transmitter service is loading…",false);
            else updateStatus(irHardware.title+(irHardware.hasEmitter?" · appliance response unverified":""),irHardware.hasEmitter);
            return;
        }
        if(!selectedUsesIr())return;
        if(infrared==null) {
            updateStatus(irCatalogFailed?"IR catalogue could not load. Restart the app to retry.":"IR catalogue is loading…",false);
        } else if(infrared.find(selected.optString("profile"))==null) {
            updateStatus("This remote is no longer in the Mi Remote catalogue. Add a matching remote again.",false);
        } else if(!irProfileError.isEmpty()) {
            updateStatus(irProfileError,false);
        } else if(!infrared.isLoaded(selected.optString("profile"))) {
            updateStatus("Loading Mi Remote signals…",false);
        } else updateStatus(irHardware.title+(irHardware.hasEmitter?" · device response unverified":""),irHardware.hasEmitter);
    }
    private int dp(float value) { return (int)(value*getResources().getDisplayMetrics().density+.5f); }
    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius));
        d.setStroke(dp(1), EDGE); return d;
    }
    private LinearLayout column() { LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout row() { LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView v=new TextView(this); v.setText(value); v.setTextColor(color); v.setTextSize(size);
        v.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL));
        v.setLineSpacing(dp(3),1); return v;
    }
    private void gap(LinearLayout into,int height) { View v=new View(this); into.addView(v,new LinearLayout.LayoutParams(1,dp(height))); }
    private Button action(String title, Runnable onClick, boolean primary) {
        Button b=new Button(this); b.setText(title); b.setTextSize(14); b.setAllCaps(false);
        b.setTextColor(primary?BG:TEXT); b.setBackground(shape(primary?MINT:CARD,16));
        b.setMinHeight(dp(52)); b.setMinimumHeight(dp(52)); b.setPadding(dp(12),0,dp(12),0);
        b.setOnClickListener(v->{v.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP); onClick.run();});
        return b;
    }
    private ImageView glyph(String kind,int color,int size) {
        ImageView icon=new ImageView(this);icon.setImageDrawable(new PalmGlyph(kind,color));
        icon.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        icon.setLayoutParams(new LinearLayout.LayoutParams(dp(size),dp(size)));return icon;
    }
    private void weighted(LinearLayout into,View view,int height) {
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(height),1); p.setMargins(dp(4),dp(4),dp(4),dp(4)); into.addView(view,p);
    }
    private void full(LinearLayout into,View view,int height) { into.addView(view,new LinearLayout.LayoutParams(-1,dp(height))); }
    private void render() {
        renderedControlsGeneration++;
        commandButtons.clear();panasonicSendButtons.clear();panasonicEditors.clear();statusText=null;
        root=column(); root.setBackgroundColor(BG); root.setPadding(dp(20),dp(8),dp(20),0);
        root.setOnApplyWindowInsetsListener((v,insets)->{
            if (android.os.Build.VERSION.SDK_INT>=30) {
                android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars());
                v.setPadding(dp(20),bars.top+dp(8),dp(20),bars.bottom);
            } else v.setPadding(dp(20),insets.getSystemWindowInsetTop()+dp(8),dp(20),insets.getSystemWindowInsetBottom());
            return insets;
        });
        setContentView(root);
        LinearLayout header=row();
        LinearLayout brand=column(); brand.addView(text("P A L M   R E M O T E",11,MINT,true)); gap(brand,4);
        brand.addView(text(currentPage.equals("Home")?"A little more control.":currentPage.equals("Remote")?"Your remote":currentPage,25,TEXT,true));
        header.addView(brand,new LinearLayout.LayoutParams(0,-2,1));
        Button plus=action("+",this::addBrand,false); plus.setContentDescription("Add a remote control");
        header.addView(plus,new LinearLayout.LayoutParams(dp(48),dp(48))); root.addView(header); gap(root,16);
        LinearLayout hardware=row();hardware.setPadding(dp(12),dp(10),dp(12),dp(10));hardware.setBackground(shape(CARD,16));
        LinearLayout hardwareLabels=column();
        irHardwareTitle=text(irHardware.title,16,TEXT,true);irHardwareTitle.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        hardwareLabels.addView(irHardwareTitle);gap(hardwareLabels,3);
        irHardwareDetail=text(irHardware.detail,12,MUTED,false);hardwareLabels.addView(irHardwareDetail);
        hardware.addView(hardwareLabels,new LinearLayout.LayoutParams(0,-2,1));
        irHardwareButton=action("Check IR",()->checkIrHardware(true),false);
        irHardwareButton.setContentDescription("Check infrared transmitter");
        LinearLayout.LayoutParams checkParams=new LinearLayout.LayoutParams(dp(105),dp(52));checkParams.setMargins(dp(8),0,0,0);
        hardware.addView(irHardwareButton,checkParams);root.addView(hardware,new LinearLayout.LayoutParams(-1,-2));gap(root,12);
        updateIrHardwareViews();
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(false); scroll.setClipToPadding(false);
        content=column(); content.setPadding(0,0,0,dp(20)); scroll.addView(content);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        if (currentPage.equals("Home")) homePage();
        else if (currentPage.equals("Remote")) remotePage();
        else if (currentPage.equals("Devices")) devicesPage(); else helpPage();
        nav=row(); nav.setPadding(0,dp(8),0,dp(8));
        for (String page:new String[]{"Home","Remote","Devices","Help"}) {
            boolean active=currentPage.equals(page);
            LinearLayout tab=column();tab.setGravity(Gravity.CENTER);tab.setPadding(0,dp(7),0,dp(7));
            tab.setBackground(shape(active?CARD:BG,16));
            tab.addView(glyph(page.toLowerCase(Locale.ROOT),active?MINT:MUTED,22));gap(tab,4);
            tab.addView(text(page,11,active?MINT:MUTED,active));
            tab.setContentDescription(page+" tab"+(active?", selected":""));tab.setFocusable(true);
            tab.setOnClickListener(v->{currentPage=page;render();});weighted(nav,tab,62);
        }
        root.addView(nav);
        root.requestApplyInsets();
    }
    private LinearLayout card(String heading,String body) {
        LinearLayout card=column(); card.setPadding(dp(18),dp(16),dp(18),dp(16)); card.setBackground(shape(CARD,20));
        if (!heading.isEmpty()) card.addView(text(heading,17,TEXT,true));
        if (!body.isEmpty()) { gap(card,8); card.addView(text(body,14,MUTED,false)); }
        content.addView(card,new LinearLayout.LayoutParams(-1,-2));gap(content,14);return card;
    }
    private void section(String title,String detail) {
        gap(content,8);content.addView(text(title,19,TEXT,true));
        if(!detail.isEmpty()){gap(content,4);content.addView(text(detail,13,MUTED,false));}gap(content,12);
    }
    private void homePage() {
        LinearLayout welcome=card("Palm Remote Demo","Crowdfunding sample · Samsung TVs; Panasonic and Midea ACs; KDK and Panasonic fans; Astro decoders. Choose an appliance and test a matching remote.");
        LinearLayout overview=row();
        TextView count=text(devices.size()+ (devices.size()==1?" saved remote":" saved remotes"),13,MINT,true);
        overview.addView(count,new LinearLayout.LayoutParams(0,-2,1));
        TextView local=text("ON THIS PHONE",10,MUTED,true);overview.addView(local);gap(welcome,14);welcome.addView(overview);
        section("Add a remote","Choose a category, then find and test a matching keyset.");
        LinearLayout first=row();categoryTile(first,"tv","Television","Samsung infrared remotes",MINT);
        categoryTile(first,"set_top_box","Decoder","Recorded IR controls",LILAC);content.addView(first);
        LinearLayout second=row();categoryTile(second,"air_conditioner","Air conditioner","Recorded IR settings",0xffffcc97);
        categoryTile(second,"fan","Fan","Speed, swing & more",0xff9ccfff);content.addView(second);gap(content,14);
        LinearLayout ac=card("Demo AC controls","Panasonic and Midea candidates are included. Test power and each available setting on your appliance. The app cannot read the AC state.");
        gap(ac,12);full(ac,action("Browse demo AC profiles",()->browseAcSource(null),false),52);
        if(!devices.isEmpty()) {
            section("Ready when you are","Tap a saved device to open its remote.");
            for(JSONObject device:devices)savedDeviceCard(device,false);
        }
        LinearLayout astro=card("Set up your Astro decoder","Five Astro remotes from Mi Remote’s regional catalogue are included. Test them with your decoder to find a match. Ultra Box, Ulti Box and NJOI model compatibility still needs confirmation on your device.");
        gap(astro,12);full(astro,action("Set up Astro",()->irSetup("Astro","set_top_box"),true),48);
        if(!notice.isEmpty())card("Notice",notice);
    }
    private void categoryTile(LinearLayout parent,String category,String title,String subtitle,int accent) {
        LinearLayout tile=column();tile.setPadding(dp(16),dp(18),dp(12),dp(15));tile.setBackground(shape(CARD,23));
        tile.addView(glyph(category,accent,34));gap(tile,14);tile.addView(text(title,15,TEXT,true));gap(tile,3);
        tile.addView(text(subtitle,11,MUTED,false));tile.setGravity(Gravity.TOP);
        tile.setContentDescription("Add "+title+" remote");tile.setFocusable(true);
        tile.setOnClickListener(v->startCategory(category));
        weighted(parent,tile,164);
    }
    private void savedDeviceCard(JSONObject device,boolean editable) {
        LinearLayout c=card("","");LinearLayout line=row();
        String category=device.optString("category","tv");line.addView(glyph(category,MINT,30));
        LinearLayout labels=column();labels.setPadding(dp(12),0,0,0);
        labels.addView(text(device.optString("name"),16,TEXT,true));gap(labels,3);
        labels.addView(text(device.optString("brand")+" · "+connectionLabel(device),12,MUTED,false));
        line.addView(labels,new LinearLayout.LayoutParams(0,-2,1));line.addView(text("›",28,MINT,false));c.addView(line);
        c.setContentDescription("Open "+device.optString("name"));c.setFocusable(true);c.setOnClickListener(v->select(device));
        if(editable) {
            gap(c,12);LinearLayout actions=row();weighted(actions,action("Open",()->select(device),true),48);
            weighted(actions,action("Remove",()->new AlertDialog.Builder(this).setTitle("Remove remote?").setMessage(device.optString("name"))
                .setNegativeButton("Cancel",null).setPositiveButton("Remove",(dialog,which)->{
                    devices.remove(device);store.delete(device.optString("id"));store.save(devices);
                    if(selected==device){selected=devices.isEmpty()?null:devices.get(0);connect();}render();}).show(),false),48);c.addView(actions);
        }
    }
    private void remotePage() {
        if (selected==null) {
            LinearLayout c=card("TVs, decoders, ACs & fans.","Choose a matching remote from the Mi Remote IR catalogue. No Palm account, subscriptions or ads.");
            gap(c,16); full(c,action("Add your first remote",this::addBrand,true),54);
            card("The right connection", "Infrared requires a compatible Android phone and a matching Mi Remote keyset. Five Astro decoder remotes are bundled for testing. This demo offers offline infrared controls only.");
            card("Built for your Android phone", "An APK cannot run on iPhone. Most Android phones also have no IR transmitter; check your phone before choosing infrared.");
            if (!notice.isEmpty()) card("Notice",notice);
            return;
        }
        if(selected.optString("mode").equals("ir")){recordedIrPage();return;}
        if(selectedUsesStatefulAc()){panasonicAcPage();return;}
        if(!usesNetwork(selected)){legacyUnavailablePage();return;}
        LinearLayout device=card(selected.optString("name"), selected.optString("brand")+"  ·  "+connectionLabel(selected));
        statusText=text(status,13,connected?MINT:MUTED,false);gap(device,8);device.addView(statusText);
        statusText.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        gap(device,10);full(device,action("Switch device  ▾",this::pickDevice,false),44);
        LinearLayout top=row(); command(top,"Power","power",true);command(top,"Input","input",false); content.addView(top);
        gap(content,12);
        LinearLayout pad=column(); pad.setPadding(dp(8),dp(8),dp(8),dp(8));pad.setBackground(shape(CARD,28));
        LinearLayout p1=row(); spacer(p1);command(p1,"▲","up",false);spacer(p1);pad.addView(p1);
        LinearLayout p2=row();command(p2,"◀","left",false);command(p2,"OK","ok",true);command(p2,"▶","right",false);pad.addView(p2);
        LinearLayout p3=row();spacer(p3);command(p3,"▼","down",false);spacer(p3);pad.addView(p3);content.addView(pad);
        LinearLayout shortcuts=row();command(shortcuts,"Back","back",false);command(shortcuts,"Home","home",false);command(shortcuts,"Menu","menu",false);content.addView(shortcuts);
        gap(content,12);
        LinearLayout sound=row();
        LinearLayout vol=column(),ch=column(),center=column();
        vol.addView(text("VOLUME",11,MUTED,true));full(vol,key("+","volume_up",false),54);gap(vol,5);full(vol,key("−","volume_down",false),54);
        center.addView(text("SOUND",11,MUTED,true));full(center,key("Mute","mute",false),54);gap(center,5);full(center,key("Info","info",false),54);
        ch.addView(text("CHANNEL",11,MUTED,true));full(ch,key("+","channel_up",false),54);gap(ch,5);full(ch,key("−","channel_down",false),54);
        weighted(sound,vol,144);weighted(sound,center,144);weighted(sound,ch,144);content.addView(sound);
        LinearLayout playback=row();command(playback,"Rewind","rewind",false);
        if(selected.optString("mode").equals("lg")) {
            command(playback,"Play","play",false);command(playback,"Pause","pause",false);
        } else command(playback,"Play / pause","play_pause",false);
        command(playback,"Forward","fast_forward",false);content.addView(playback);
        LinearLayout guide=row();command(guide,"Guide","guide",false);guide.addView(action("123  Keypad",this::keypad,false),new LinearLayout.LayoutParams(0,dp(56),1));content.addView(guide);
        gap(content,14);
        full(content,action("Reconnect",this::connect,false),48);
        gap(content,14);
        content.addView(text("Only buttons supported by this connection are enabled. Pairing and model support depend on your TV.",12,MUTED,false));
        if (!notice.isEmpty()) {gap(content,10);content.addView(text(notice,13,MUTED,false));}
        refreshButtons();
    }
    private boolean usesNetwork(JSONObject device) {
        String mode=device.optString("mode");return mode.equals("lg")||mode.equals("smartthings");
    }
    private void legacyUnavailablePage() {
        updateStatus("This saved remote is unavailable in the Mi Remote catalogue.",false);
        deviceHeading();
        card("Choose a replacement remote", "This older remote cannot send commands in this version. Add a recorded remote from the Mi Remote catalogue for your appliance. You can remove this old entry from Devices.");
        full(content,action("Add a recorded remote",this::addBrand,true),54);gap(content,12);
        full(content,action("Open saved devices",()->{currentPage="Devices";render();},false),48);
    }
    private String connectionLabel(JSONObject device) {
        switch(device.optString("mode")) { case "ir":return "Mi Remote infrared";case "panasonic_ac":return "Panasonic AC infrared";case "family_ac":return "Experimental AC infrared";case "lg":return "Local Wi-Fi";case "smartthings":return "SmartThings cloud";default:return "Unavailable legacy remote"; }
    }
    private void spacer(LinearLayout row) { row.addView(new View(this),new LinearLayout.LayoutParams(0,dp(58),1)); }
    private void command(LinearLayout row,String label,String code,boolean primary) { weighted(row,key(label,code,primary),58); }
    private Button key(String label,String code,boolean primary) {
        Button b=action(label,()->send(code),primary); b.setContentDescription(label);commandButtons.put(b,code);return b;
    }
    private String labelFor(String code) { return code.replace('_',' '); }
    private RemoteCommand networkCommand(String code) {
        String name=code.equals("ok")?"SELECT":code.equals("input")?"SOURCE":code.toUpperCase(Locale.ROOT);
        try{return RemoteCommand.valueOf(name);}catch(Exception e){return null;}
    }
    private boolean supports(String code) {
        if (selected==null || !connected || busy) return false;
        if (selected.optString("mode").equals("ir")) return infrared!=null && infrared.supports(selected.optString("profile"),code);
        if(!usesNetwork(selected))return false;
        RemoteCommand command=networkCommand(code);if(command==null)return false;
        if (cloud!=null && cloudDevice!=null) {
            if(code.equals("input")) return cloudDevice.getCapabilities().contains("mediaInputSource");
            return cloud.supports(command,cloudDevice);
        }
        return network!=null && network.supports(command);
    }
    private void refreshButtons() {
        for (Map.Entry<View,String> entry:commandButtons.entrySet()) {
            boolean enabled=supports(entry.getValue());entry.getKey().setEnabled(enabled);entry.getKey().setAlpha(enabled?1f:.3f);
        }
        boolean acReady=selectedUsesStatefulAc()&&infrared!=null&&irHardware.hasEmitter&&!busy
            &&currentAcProfile()!=null;
        for(View button:panasonicSendButtons){button.setEnabled(acReady);button.setAlpha(acReady?1f:.3f);}
        for(View editor:panasonicEditors)editor.setEnabled(!busy);
    }
    private void updateStatus(String value,boolean ready) {
        status=value;connected=ready;
        if(statusText!=null && currentPage.equals("Remote")) {statusText.setText(value);statusText.setTextColor(ready?MINT:MUTED);}
        refreshButtons();
    }
    private void send(String command) {
        if (!supports(command)) {message("This button is unavailable for this connection.");return;}
        if(command.equals("input") && cloud!=null){cloudInput();return;}
        final JSONObject device=selected; final long generation=connectionGeneration;
        final NetworkRemote targetNetwork=network; final SmartThingsClient targetCloud=cloud;
        final SmartThingsClient.Device targetCloudDevice=cloudDevice;
        busy=true;refreshButtons();
        worker.execute(()->{
            try {
                if (device.optString("mode").equals("ir")) infrared.transmit(device.optString("profile"),command);
                else if (targetCloud!=null) targetCloud.send(networkCommand(command),targetCloudDevice);
                else if(targetNetwork!=null) targetNetwork.send(networkCommand(command));
                else throw new IllegalStateException("Connect the TV first.");
                ui(()->{if(generation==connectionGeneration)updateStatus(device.optString("mode").equals("ir")?"IR sent · "+commandLabel(device,command):"Command sent · "+labelFor(command),true);});
            }catch(Exception error){ui(()->{if(generation==connectionGeneration) {updateStatus(error.getMessage(),connected);message(error.getMessage());}});}
            finally {ui(()->{if(generation==connectionGeneration){busy=false;refreshButtons();}});}
        });
    }
    private void connect() {
        connectionGeneration++; final long generation=connectionGeneration;
        if (network!=null) network.dispose(); network=null;cloud=null;cloudDevice=null;connected=false;busy=false;
        irProfileError="";
        if(selected==null)return;
        JSONObject device=selected;
        if(selectedUsesStatefulAc()){updateIrRemoteAvailability();return;}
        if(device.optString("mode").equals("ir")) {
            updateIrRemoteAvailability();
            if(infrared==null||infrared.isLoaded(device.optString("profile")))return;
            final IrCatalog catalogue=infrared;
            worker.execute(()->{
                try {
                    catalogue.loadProfile(device.optString("profile"));
                    ui(()->{if(generation==connectionGeneration){render();updateIrRemoteAvailability();}});
                }catch(Exception error){
                    ui(()->{if(generation==connectionGeneration){irProfileError="Signals could not load: "+error.getMessage();render();updateIrRemoteAvailability();}});
                }
            });
            return;
        }
        if(!usesNetwork(device)) {
            updateStatus("This saved remote is unavailable in the Mi Remote catalogue.",false);return;
        }
        updateStatus("Connecting…",false);
        worker.execute(()->{
            try {
                if(device.optString("mode").equals("lg")) {
                    NetworkRemote remote=new NetworkRemote(new DeviceEndpoint(TvPlatform.LG_WEBOS,device.getString("host"),store.credential(device.getString("id"))),
                        result->ui(()->{if(generation==connectionGeneration)updateStatus(result.getMessage(),result.getPhase()==RemoteStatus.Phase.READY);}),
                        credential->{try{store.putCredential(device.optString("id"),credential);}catch(Exception e){ui(()->message("Could not save the TV pairing. Pair again next time."));}});
                    ui(()->{if(generation==connectionGeneration)network=remote;else remote.dispose();});
                    remote.connect();
                }else {
                    SmartThingsClient client=new SmartThingsClient(store.credential(device.getString("id")));
                    SmartThingsClient.Device match=null;
                    for(SmartThingsClient.Device candidate:client.listDevices())if(candidate.getId().equals(device.getString("cloudId")))match=candidate;
                    if(match==null)throw new IllegalStateException("This device was not returned by SmartThings. Check token permissions or add it again.");
                    SmartThingsClient.Device found=match;
                    ui(()->{if(generation==connectionGeneration){cloud=client;cloudDevice=found;updateStatus("SmartThings connected · internet required",true);}});
                }
            }catch(Exception error){ui(()->{if(generation==connectionGeneration)updateStatus(error.getMessage(),false);});}
        });
    }
    private void devicesPage() {
        card("Your devices",devices.isEmpty()?"Add a TV, decoder, air conditioner or fan. Your device list stays on this phone.":"Saved on this phone. Tap a device to open its remote.");
        for(JSONObject device:devices)savedDeviceCard(device,true);
        full(content,action("+ Add a remote",this::addBrand,true),54);gap(content,12);
    }
    private void helpPage() {
        card("Palm Remote Demo","Crowdfunding sample based on Palm Remote 1.6.6. Included brands: Samsung TVs; Panasonic and Midea air conditioners; KDK and Panasonic fans; Astro decoders. Other brands and their remote assets are excluded from this APK.");
        card("Find a working remote","Choose a category and brand, then Find a working remote · Guided testing. Aim your IR-equipped Android phone at the appliance. Confirm actual responses before saving a match. A brand match alone does not prove model compatibility.");
        card("AC settings","Panasonic parameter controls and experimental Panasonic/Midea AC112 candidates are included. Offered fan, swing, timer and special options depend on the selected profile. Test each function; the app cannot read appliance state. Timers run on the appliance after a successful IR request.");
        card("Astro setup","Five Astro candidates are included. Confirm multiple button responses before saving. Ultra Box, Ulti Box and NJOI model compatibility requires testing.");
        card("Phone infrared","A detected built-in Android IR transmitter is required for sending. Without one you can browse and save an explicitly untested preview. Hardware detection does not prove the appliance responded.");
        card("Demo data","This is a separate app with its own local saved remotes. No account, payment or crowdfunding pledge is collected in the app. The demo uses offline IR controls.");
        card("Test status","Automated catalogue, encoder and build checks do not establish physical appliance compatibility. Confirm the intended effect on your own appliance.");
    }
    private void addBrand() {
        String[] labels={"Television","Set-top box / decoder","Air conditioner","Fan"};
        String[] categories={"tv","set_top_box","air_conditioner","fan"};
        new AlertDialog.Builder(this).setTitle("Add a device").setItems(labels,(dialog,index)->{
            startCategory(categories[index]);
        }).setNegativeButton("Cancel",null).show();
    }
    private void startCategory(String category) {
        if(category.equals("set_top_box")) {
            new AlertDialog.Builder(this).setTitle("Mi Remote decoder catalogue")
                .setMessage("Choose Astro, then Find a working remote · Guided testing. Aim an IR-equipped phone at the decoder and confirm actual button responses. Five Astro candidates are included; Ultra Box, Ulti Box and NJOI model matches require testing.")
                .setPositiveButton("Browse brands",(d,w)->categoryBrands(category)).setNegativeButton("Cancel",null).show();
        }else categoryBrands(category);
    }
    private String categoryLabel(String category) {
        switch(category){case "set_top_box":return "Decoder";case "air_conditioner":return "Air-conditioner";case "fan":return "Fan";default:return "TV";}
    }
    private void categoryBrands(String category) {
        if(infrared==null){message(irCatalogFailed?"The IR catalogue could not load. Restart the app to retry.":"The IR catalogue is loading. Try again in a moment.");return;}
        Set<String> brands=new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        brands.addAll(infrared.brands(category));
        if(category.equals("air_conditioner")) {
            if(acSourceDatabase==null&&!acSourceFailed){message("The AC source catalogue is loading. Try again shortly.");return;}
            brands.addAll(new AcGuidedCatalog(infrared,acSourceDatabase,panasonic,familyAc).brands());
        }
        // These two connection options remain available independently of the IR catalogue.
        if(category.equals("tv"))brands.add("Samsung");
        Iterator<String> demoBrands=brands.iterator();while(demoBrands.hasNext())if(!DemoScope.allowed(category,demoBrands.next()))demoBrands.remove();
        List<Choice> options=new ArrayList<>();
        for(String brand:brands)options.add(new Choice(brand,()->{
            chooseMethod(brand,category);
        }));
        if(options.isEmpty()){message("No decoded "+categoryLabel(category).toLowerCase(Locale.ROOT)+" profiles are available in this snapshot.");return;}
        choices(categoryLabel(category)+" brand · Mi Remote",options);
    }
    private void browseAcSource(String brand) {
        if(acSourceDatabase==null){message(acSourceFailed?"The complete AC database could not load. Existing remotes remain available.":"The complete AC database is loading. Try again shortly.");return;}
        List<Choice> options=new ArrayList<>();
        for(JSONObject profile:acSourceDatabase.profiles(brand)) {
            String status=FamilyAcEncoder.supports(profile.optString("model"))?"Experimental protocol candidate":profile.optJSONObject("control").optString("kind").equals("unavailable")?"Data included · controls unavailable":"Controls available";
            options.add(new Choice(profile.optString("brand")+" · "+profile.optString("model")+" · "+status,()->showAcSourceDetails(profile)));
        }
        choices((brand==null?"All 46 demo AC source profiles":brand+" · "+options.size()+" Mi APK AC profiles"),options);
    }
    private void showAcSourceDetails(JSONObject profile) {
        String kind=profile.optJSONObject("control").optString("kind");boolean available=!kind.equals("unavailable");
        String details=(FamilyAcEncoder.supports(profile.optString("model"))?"An experimental protocol candidate is available for this source template. These controls use a public protocol mapping and have not been tested on your appliance. Only the implemented controls shown for the selected candidate are offered. Expanded AC112 candidates expose power, Cool/Heat and 16–30 °C; fan and swing use reviewed source tables, and timer and special functions are offered only where mapped. Source hooks are never executed.\n\n":"")+"Complete source data included offline.\n\n"+(FamilyAcEncoder.supports(profile.optString("model"))?"Exact source-engine equivalence remains unverified; use Try protocol candidate to test the independent encoder.":available?"Controls available: "+(kind.equals("recorded")?"recorded signals":"Panasonic temperature and mode controls")+".":"Data included; controls unavailable. This stateful profile needs an encoder. No signal can be sent from this source-data view.")
            +"\n\nSource profile: "+profile.optString("model")+"\nBrand: "+profile.optString("brand")
            +"\nCarrier: "+profile.optInt("carrierHz")+" Hz\nDefinition fields: "+profile.optInt("definitionFieldCount")
            +"\nIR hardware: "+irHardware.title+"\n\nSource IDs are not retail model numbers. Included data does not establish an appliance match.";
        AlertDialog.Builder builder=new AlertDialog.Builder(this).setTitle("AC source · "+profile.optString("model"))
            .setMessage(details).setNeutralButton("View included data",(dialog,which)->viewAcSourceData(profile));
        if(FamilyAcEncoder.supports(profile.optString("model")))builder.setPositiveButton("Try protocol candidate",(dialog,which)->panasonicSetup(null,"family_"+profile.optString("model"))).setNegativeButton("Close",null);
        else if(available)builder.setPositiveButton("Open controls",(dialog,which)->openAcSourceControls(profile)).setNegativeButton("Close",null);
        else builder.setPositiveButton("Close",null);
        builder.show();
    }
    private void openAcSourceControls(JSONObject profile) {
        JSONObject control=profile.optJSONObject("control");String kind=control.optString("kind"),id=control.optString("profile");
        if(kind.equals("recorded")) {
            JSONObject target=infrared==null?null:infrared.find(id);
            if(target==null||!target.optString("model").equals(profile.optString("model"))
                ||!target.optJSONObject("source").optString("sourceSha256").equals(profile.optString("sourceRecordSha256"))) {
                message("The recorded control link is unavailable. Source data remains included.");return;
            }
            matchIrProfiles(target.optString("brand"),Collections.singletonList(target));
        }else if(kind.equals("panasonic216")) {
            JSONObject target=panasonic==null?null:panasonic.find(id);
            if(target==null||!target.optString("model").equals(profile.optString("model"))) {
                message("The Panasonic controls are unavailable. Source data remains included.");return;
            }
            panasonicSetup(null,id);
        }
    }
    private void viewAcSourceData(JSONObject profile) {
        final AcSourceDatabase database=acSourceDatabase;
        if(database==null){message("The AC source database is unavailable.");return;}
        acSourceWorker.execute(()->{
            try {
                String data=database.readRecord(profile.optString("id")).toString(2);
                ui(()->{
                    LinearLayout body=column();body.setPadding(dp(18),dp(8),dp(18),dp(8));
                    body.addView(text("Included source data only. Stored script text is never executed. This view cannot transmit IR.",13,MUTED,false));gap(body,12);
                    TextView source=text(data,11,TEXT,false);source.setTextIsSelectable(true);
                    ScrollView scroll=new ScrollView(this);scroll.addView(source);body.addView(scroll,new LinearLayout.LayoutParams(-1,dp(320)));
                    new AlertDialog.Builder(this).setTitle("Included AC data · "+profile.optString("model")).setView(body).setPositiveButton("Done",null).show();
                });
            }catch(Exception error){ui(()->message("Could not read included AC data: "+error.getMessage()));}
        });
    }
    private static final class Choice {
        final String label;final Runnable action;
        Choice(String label,Runnable action){this.label=label;this.action=action;}
        @Override public String toString(){return label;}
    }
    private void choices(String title,List<Choice> options) { choices(title,options,""); }
    private void choices(String title,List<Choice> options,String note) {
        LinearLayout body=column();body.setPadding(dp(18),0,dp(18),0);
        if(!note.isEmpty()){body.addView(text(note,13,MUTED,false));gap(body,8);}
        EditText search=input("Search this list",false);body.addView(search);
        ListView list=new ListView(this);body.addView(list,new LinearLayout.LayoutParams(-1,dp(330)));
        List<Choice> filtered=new ArrayList<>(options);
        ArrayAdapter<Choice> adapter=new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,filtered);list.setAdapter(adapter);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(title).setView(body).setNegativeButton("Cancel",null).create();
        search.addTextChangedListener(new android.text.TextWatcher(){
            public void beforeTextChanged(CharSequence s,int start,int count,int after){}
            public void onTextChanged(CharSequence s,int start,int before,int count){
                filtered.clear();String query=s.toString().toLowerCase(Locale.ROOT);
                for(Choice choice:options)if(choice.label.toLowerCase(Locale.ROOT).contains(query))filtered.add(choice);
                adapter.notifyDataSetChanged();
            }
            public void afterTextChanged(android.text.Editable e){}
        });
        list.setOnItemClickListener((parent,view,index,id)->{Choice choice=filtered.get(index);dialog.dismiss();choice.action.run();});
        dialog.show();
        dialog.getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
    }
    private void deviceHeading() {
        LinearLayout device=card(selected.optString("name"),selected.optString("brand")+" · "+connectionLabel(selected));
        statusText=text(status,13,connected?MINT:MUTED,false);statusText.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        gap(device,8);device.addView(statusText);gap(device,10);full(device,action("Switch device  ▾",this::pickDevice,false),44);
    }
    private boolean ensurePanasonicDraft(JSONObject profile) {
        String identity=selected.optString("id")+"|"+selected.optString("profile");
        if(identity.equals(panasonicDraftDeviceId)&&panasonicDraft!=null)return true;
        panasonicDraftDeviceId=identity;acTimerMinutes[0]=60;acTimerMinutes[1]=60;
        try{panasonicDraft=PanasonicAcEncoder.defaults(profile);}catch(Exception error){panasonicDraft=null;return false;}
        try {
            JSONObject saved=selected.optJSONObject("requestedState");
            if(saved!=null) {
                PanasonicAcEncoder.State restored=PanasonicAcEncoder.State.fromJson(saved);
                encodeAc(profile,restored,false);
                panasonicDraft=restored;
            }
        }catch(Exception ignored){/* Invalid saved requests become a safe draft, never an automatic transmission. */}
        return true;
    }
    private interface IndexChoice { void choose(int index); }
    private Spinner acSelector(LinearLayout parent,String heading,List<String> labels,int current,IndexChoice chosen) {
        final long generation=renderedControlsGeneration;
        parent.addView(text(heading,12,MUTED,true));gap(parent,4);
        Spinner spinner=new Spinner(this);
        ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,labels);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);spinner.setAdapter(adapter);
        spinner.setSelection(Math.max(0,Math.min(current,labels.size()-1)));
        spinner.setContentDescription(heading);parent.addView(spinner,new LinearLayout.LayoutParams(-1,dp(48)));
        panasonicEditors.add(spinner);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override public void onItemSelected(AdapterView<?> p,View v,int position,long id){
                if(!destroyed&&!busy&&generation==renderedControlsGeneration&&position>=0&&position<labels.size())chosen.choose(position);
            }
            @Override public void onNothingSelected(AdapterView<?> p){}
        });
        gap(parent,12);return spinner;
    }
    private Button acSendButton(String label,Runnable send,boolean primary) {
        Button button=action(label,send,primary);panasonicSendButtons.add(button);return button;
    }
    private void panasonicAcPage() {
        deviceHeading();
        JSONObject profile=currentAcProfile();
        if(profile==null) {
            card("AC definitions",panasonicFailed?"The bundled AC definitions could not load. Other remotes remain available.":"Loading the bundled AC definitions…");return;
        }
        if(!ensurePanasonicDraft(profile)){card("AC profile unavailable","The saved AC definition could not be validated. Choose another profile.");return;}
        boolean toggle=profile.optBoolean("powerToggle");
        card("Requested settings", "These controls prepare a complete AC message. They do not read the air conditioner's current state. Nothing is sent until you tap a send or power button.");
        LinearLayout controls=card(profile.optString("brand")+" AC · "+profile.optString("model"),toggle?"Power uses a toggle signal; the actual on/off state is unknown.":"Requested power: "+(panasonicDraft.power?"On":"Off"));
        TextView temperature=text(panasonicDraft.temperature+" °C",34,MINT,true);temperature.setGravity(Gravity.CENTER);controls.addView(temperature);gap(controls,8);
        LinearLayout temperatureButtons=row();
        Button lower=action("Temperature −",()->{if(!busy&&panasonicDraft.temperature>16){panasonicDraft.temperature--;temperature.setText(panasonicDraft.temperature+" °C");}},false);
        Button higher=action("Temperature +",()->{if(!busy&&panasonicDraft.temperature<30){panasonicDraft.temperature++;temperature.setText(panasonicDraft.temperature+" °C");}},false);
        panasonicEditors.add(lower);panasonicEditors.add(higher);
        weighted(temperatureButtons,lower,52);weighted(temperatureButtons,higher,52);
        controls.addView(temperatureButtons);gap(controls,12);
        List<String> modes=new ArrayList<>();JSONArray sourceModes=profile.optJSONArray("modes");
        if(sourceModes!=null)for(int i=0;i<sourceModes.length();i++)modes.add(sourceModes.optString(i));
        if(!modes.isEmpty())acSelector(controls,"Mode",modes,modes.indexOf(panasonicDraft.mode),index->panasonicDraft.mode=modes.get(index));
        if(!profile.optBoolean("expanded")&&profile.optBoolean("supportsFan"))acSelector(controls,"Fan speed",Arrays.asList("Auto","Low","Medium","High"),panasonicDraft.fan,index->panasonicDraft.fan=index);
        if(!profile.optBoolean("expanded")&&profile.optBoolean("supportsSwing"))acSelector(controls,"Vertical swing",Arrays.asList("Auto swing","Position 1","Position 2","Position 3","Position 4","Position 5"),panasonicDraft.swing,index->panasonicDraft.swing=index);
        if(profile.optBoolean("expanded"))expandedFanAndSwing(controls,profile);
        full(controls,acSendButton("Send requested settings",()->sendPanasonic(panasonicDraft.copy(),false,"requested settings"),true),54);gap(controls,10);
        if(toggle) {
            full(controls,acSendButton("Send power toggle",()->sendPanasonic(panasonicDraft.copy(),true,"power toggle"),false),52);
        } else {
            LinearLayout power=row();
            weighted(power,acSendButton("Power on",()->{PanasonicAcEncoder.State next=panasonicDraft.copy();next.power=true;sendPanasonic(next,true,"power on");},false),52);
            weighted(power,acSendButton("Power off",()->{PanasonicAcEncoder.State next=panasonicDraft.copy();next.power=false;sendPanasonic(next,true,"power off");},false),52);
            controls.addView(power);
        }
        if(!profile.optBoolean("supportsFan")) {gap(controls,12);controls.addView(text("This source profile has no verified fan-speed mapping; its captured default is preserved.",12,MUTED,false));}
        if(profile.optBoolean("expanded"))expandedAdditionalControls(profile);
        if(profile.has("family"))card("Experimental protocol candidate", "Physical appliance response and exact equivalence to Mi Remote are unverified. Test power and each offered setting. Additional functions depend on the selected definition.");
        gap(content,8);full(content,action(profile.has("family")?"Find a different AC remote":"Find a different Panasonic remote",()->panasonicSetup(selected),false),48);
        gap(content,12);content.addView(text("Source keyset: "+profile.optString("model")+". Protocol and source keyset IDs are candidates; confirm the appliance responds before treating them as a match.",12,MUTED,false));
        refreshButtons();
    }
    private void setAcExtra(String fid,Integer value) {
        try{if(value==null)panasonicDraft.extras.remove(fid);else panasonicDraft.extras.put(fid,value);}
        catch(Exception error){message("Could not prepare that AC function.");}
    }
    private void expandedFanAndSwing(LinearLayout controls,JSONObject profile) {
        JSONObject mappings=profile.optJSONObject("additionalControls");if(mappings==null)return;
        acSelector(controls,"Fan speed",Arrays.asList("Keep captured fan setting","Auto","Low","Medium","High"),panasonicDraft.fan+1,index->panasonicDraft.fan=index-1);
        full(controls,acSendButton("Send fan speed",()->sendPanasonic(panasonicDraft.copy(),false,"fan speed"),false),50);gap(controls,12);
        List<String> swings=new ArrayList<>();swings.add("Keep captured swing setting");
        JSONArray labels=mappings.optJSONArray("swingLabels");if(labels!=null)for(int i=0;i<labels.length();i++)swings.add(labels.optString(i));
        acSelector(controls,"Vertical swing",swings,panasonicDraft.swing+1,index->panasonicDraft.swing=index-1);
        full(controls,acSendButton("Send swing",()->sendPanasonic(panasonicDraft.copy(),false,"vertical swing"),false),50);gap(controls,12);
    }
    private void sendAcTimer(int fid,int minutes) {
        try{
            PanasonicAcEncoder.State request=panasonicDraft.copy();request.extras.remove("9");request.extras.remove("10");request.extras.put(Integer.toString(fid),minutes);
            sendPanasonic(request,false,minutes==0?"cancel timers":(fid==9?"power-on":"power-off")+" timer · "+minutes+" min");
        }catch(Exception error){message("Could not prepare the AC timer.");}
    }
    private void expandedAdditionalControls(JSONObject profile) {
        JSONObject mappings=profile.optJSONObject("additionalControls");if(mappings==null)return;
        LinearLayout timers=card("AC timers","Countdowns run on the appliance. Sending a timer can also change the requested settings. Timer commands are sent once and are not repeated by ordinary settings or power buttons.");
        if(mappings.optInt("timerHook")==0){
            timers.addView(text("This definition has no reviewed timer encoding. Timer buttons are unavailable for this candidate.",13,MUTED,false));
            Button unavailable=action("Timers unavailable",()->{},false);unavailable.setEnabled(false);full(timers,unavailable,48);
        }else{
            int min=mappings.optInt("timerMin"),max=mappings.optInt("timerMax"),step=mappings.optInt("timerStep");
            List<String> labels=new ArrayList<>();final List<Integer> values=new ArrayList<>();
            for(int value=Math.max(min,step);value<=max;value+=step){values.add(value);labels.add(value+" min"+(value%60==0?" · "+value/60+" h":""));}
            for(int i=0;i<2;i++){
                final int timer=i;int current=values.indexOf(acTimerMinutes[i]);if(current<0){current=0;acTimerMinutes[i]=values.get(0);}
                acSelector(timers,i==0?"Power-on countdown":"Power-off countdown",labels,current,index->acTimerMinutes[timer]=values.get(index));
                full(timers,acSendButton(i==0?"Set power-on timer":"Set power-off timer",()->sendAcTimer(timer==0?9:10,acTimerMinutes[timer]),false),50);gap(timers,10);
            }
            full(timers,acSendButton("Cancel AC timers",()->sendAcTimer(9,0),false),50);
            gap(timers,8);timers.addView(text("Only one countdown is encoded at a time; setting one clears the other in the requested packet. Check the AC's timer indicator and actual behavior.",12,MUTED,false));
        }
        LinearLayout special=card("Special functions","Only functions with reviewed mappings in this source definition are offered. Labels describe source functions; appliance support is experimental. Sleep / night fan overrides fan speed when enabled. Auxiliary heat requires Heat mode.");
        JSONObject features=mappings.optJSONObject("extras");List<String> keys=new ArrayList<>();if(features!=null){Iterator<String> it=features.keys();while(it.hasNext())keys.add(it.next());}
        Collections.sort(keys,(a,b)->Integer.compare(Integer.parseInt(a),Integer.parseInt(b)));
        for(String fid:keys){
            JSONObject feature=features.optJSONObject(fid);JSONArray options=feature.optJSONArray("options");
            List<String> labels=new ArrayList<>();labels.add("Keep captured setting");List<Integer> values=new ArrayList<>();values.add(null);
            for(int i=0;i<options.length();i++){JSONObject option=options.optJSONObject(i);labels.add(option.optString("label"));values.add(option.optInt("value"));}
            int current=panasonicDraft.extras.has(fid)?values.indexOf(panasonicDraft.extras.optInt(fid)):0;
            acSelector(special,feature.optString("label"),labels,current,index->setAcExtra(fid,values.get(index)));
        }
        if(keys.isEmpty()){
            special.addView(text("No special-function mapping is available for this definition.",13,MUTED,false));Button unavailable=action("Special functions unavailable",()->{},false);unavailable.setEnabled(false);full(special,unavailable,48);
        }else full(special,acSendButton("Send special functions",()->sendPanasonic(panasonicDraft.copy(),false,"special functions"),false),50);
        card("Experimental AC112 controls","Fan and swing use this definition’s tables. Timer and special buttons appear only where reviewed mappings exist. Keep captured setting preserves the source template, not the AC’s live state. Test each function and both timing variants.");
    }
    private void sendPanasonic(PanasonicAcEncoder.State requested,boolean powerButtonPress,String label) {
        if(!selectedUsesStatefulAc()||currentAcProfile()==null||infrared==null||!irHardware.hasEmitter||busy){message("A detected built-in IR transmitter and a loaded AC profile are required.");return;}
        final JSONObject device=selected,profile=currentAcProfile();
        if(profile==null){message("Choose a supported AC profile first.");return;}
        final IrCatalog transmitter=infrared;final long generation=connectionGeneration;
        final PanasonicAcEncoder.State snapshot=requested.copy(),persisted=Ac112Controls.persistentRequest(snapshot,panasonicDraft);
        busy=true;refreshButtons();
        worker.execute(()->{
            try {
                if(destroyed||generation!=connectionGeneration||selected!=device)return;
                PanasonicAcEncoder.Signal signal=encodeAc(profile,snapshot,powerButtonPress);
                if(destroyed||generation!=connectionGeneration||selected!=device)return;
                transmitter.transmitSignal(signal.carrierHz,signal.pattern);
                ui(()->{
                    if(generation!=connectionGeneration||selected!=device)return;
                    try {device.put("requestedState",persisted.toJson());store.save(devices);panasonicDraft=persisted.copy();}
                    catch(Exception ignored){message("IR was sent, but the requested settings could not be saved.");}
                    updateStatus("IR sent · "+label+". Confirm the AC responds.",true);render();
                });
            }catch(Exception error){ui(()->{if(generation==connectionGeneration){updateStatus("Signal could not be sent: "+error.getMessage(),irHardware.hasEmitter);message(error.getMessage());}});}
            finally{ui(()->{if(generation==connectionGeneration){busy=false;refreshButtons();}});}
        });
    }
    private void panasonicSetup() { panasonicSetup(null); }
    private void panasonicSetup(JSONObject replacement) {
        panasonicSetup(replacement,"");
    }
    private void panasonicSetup(JSONObject replacement,String initialProfile) { panasonicSetup(replacement,initialProfile,null); }
    private void panasonicSetup(JSONObject replacement,String initialProfile,List<JSONObject> allowedProfiles) {
        final boolean familyMode=initialProfile.startsWith("family_")||(replacement!=null&&replacement.optString("mode").equals("family_ac"));
        final PanasonicAcEncoder encoder=panasonic;
        if(!familyMode&&encoder==null){message(panasonicFailed?"Panasonic AC definitions could not load. Recorded AC remotes remain available.":"Panasonic AC definitions are loading. Try again shortly.");return;}
        if(familyMode&&familyAc==null){message("AC protocol candidates are loading.");return;}
        String requestedProfileId=replacement==null?initialProfile:replacement.optString("profile");
        final List<JSONObject> profiles=allowedProfiles!=null?new ArrayList<>(allowedProfiles):familyMode?familyAc.profiles():encoder.profiles();
        if(familyMode&&allowedProfiles==null) {
            JSONObject requested=familyAc.find(requestedProfileId);
            if(requested==null){message("This AC protocol candidate is unavailable.");return;}
            String selectedBrand=requested.optString("brand");
            Iterator<JSONObject> candidates=profiles.iterator();
            while(candidates.hasNext())if(!candidates.next().optString("brand").equalsIgnoreCase(selectedBrand))candidates.remove();
        }
        if(profiles.isEmpty()){message("No implemented AC parameter candidates are available.");return;}
        int initial=0;for(int i=0;i<profiles.size();i++)if(profiles.get(i).optString("id").equals(requestedProfileId))initial=i;
        final int[] current={initial};final boolean[] sending={false},signalSent={false};
        final java.util.concurrent.atomic.AtomicBoolean active=new java.util.concurrent.atomic.AtomicBoolean(true);
        LinearLayout body=column();body.setPadding(dp(20),dp(8),dp(20),dp(12));
        TextView position=text("",17,TEXT,true);body.addView(position);gap(body,10);
        body.addView(text("Try each candidate while aiming at the AC. The test requests Cool at 24 °C. Only you can confirm whether the appliance responds. These source IDs are not retail model numbers.",13,MUTED,false));gap(body,12);
        TextView result=text("",13,MUTED,false);result.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);body.addView(result);gap(body,12);
        Button test=action("Test AC signal",()->{},true);full(body,test,60);gap(body,12);
        LinearLayout pages=row();Button previous=action("Previous",()->{},false),next=action("Next remote",()->{},false);weighted(pages,previous,48);weighted(pages,next,48);body.addView(pages);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(familyMode?"Try an AC protocol candidate":"Find a Panasonic AC remote").setView(body)
            .setNegativeButton("Close",null).setNeutralButton("Save preview",null).setPositiveButton("Use this remote",null).create();
        Runnable refresh=()->{
            JSONObject profile=profiles.get(current[0]);
            position.setText("AC remote "+(current[0]+1)+" of "+profiles.size()+" · "+profile.optString("model")+(profile.optBoolean("expanded")?" · "+profile.optString("family"):""));
            test.setText(profile.optBoolean("powerToggle")?"Test power toggle · Cool 24 °C":"Test power on · Cool 24 °C");
            test.setEnabled(!sending[0]&&irHardware.hasEmitter&&infrared!=null);
            result.setText(irHardware.hasEmitter?"Tap the test button once, then check the AC yourself.":irHardware.title+". You can save a preview; infrared sending remains disabled.");
            previous.setEnabled(!sending[0]&&current[0]>0);next.setEnabled(!sending[0]&&current[0]<profiles.size()-1);
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(!sending[0]&&signalSent[0]);
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setEnabled(!sending[0]);
        };
        previous.setOnClickListener(v->{if(!sending[0]&&current[0]>0){current[0]--;signalSent[0]=false;refresh.run();}});
        next.setOnClickListener(v->{if(!sending[0]&&current[0]<profiles.size()-1){current[0]++;signalSent[0]=false;refresh.run();}});
        test.setOnClickListener(v->{
            if(sending[0]||!irHardware.hasEmitter||infrared==null)return;
            final int tested=current[0];final JSONObject profile=profiles.get(tested);final IrCatalog transmitter=infrared;
            sending[0]=true;test.setEnabled(false);previous.setEnabled(false);next.setEnabled(false);
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setEnabled(false);
            result.setText("Sending the requested AC test message…");
            worker.execute(()->{
                boolean accepted=false;String outcome;
                try {
                    if(destroyed||!active.get())return;
                    PanasonicAcEncoder.State requested=PanasonicAcEncoder.defaults(profile);
                    PanasonicAcEncoder.Signal signal=encodeAc(profile,requested,true);
                    if(destroyed||!active.get())return;
                    transmitter.transmitSignal(signal.carrierHz,signal.pattern);accepted=true;
                    outcome="IR sent. Did the AC respond? Confirm only if it did, or try the next remote.";
                }catch(Exception error){outcome="Signal could not be sent: "+error.getMessage();}
                final boolean sent=accepted;final String message=outcome;
                ui(()->{
                    if(!active.get()||tested!=current[0])return;
                    sending[0]=false;signalSent[0]|=sent;refresh.run();result.setText(message);
                });
            });
        });
        dialog.setOnDismissListener(d->active.set(false));
        dialog.setOnShowListener(d->{
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v->{
                if(sending[0])return;JSONObject profile=profiles.get(current[0]);
                new AlertDialog.Builder(this).setTitle("Save an untested preview?")
                    .setMessage("This saves the selected controls without claiming they work with your AC. No infrared signal is sent by saving. Sending still requires a detected built-in emitter.")
                    .setNegativeButton("Keep testing",null).setPositiveButton("Save preview",(confirm,which)->{dialog.dismiss();savePanasonic(profile,false,replacement);}).show();
            });
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
                if(sending[0]||!signalSent[0])return;JSONObject profile=profiles.get(current[0]);
                new AlertDialog.Builder(this).setTitle("Did your AC respond?")
                    .setMessage("Save this candidate as tested only if the AC responded correctly. Check other settings after saving; Palm cannot read the appliance's state.")
                    .setNegativeButton("Keep testing",null).setPositiveButton("Yes, save remote",(confirm,which)->{dialog.dismiss();savePanasonic(profile,true,replacement);}).show();
            });refresh.run();
        });dialog.show();
    }
    private void savePanasonic(JSONObject profile,boolean responseConfirmed,JSONObject replacement) {
        try {
            String brand=profile.getString("brand"),mode=profile.has("family")?"family_ac":"panasonic_ac";
            JSONObject device=replacement==null?baseDevice(brand,mode,brand+" AC · "+profile.getString("model")):new JSONObject(replacement.toString());
            device.put("name",brand+" AC · "+profile.getString("model")).put("brand",brand).put("mode",mode)
                .put("profile",profile.getString("id")).put("category","air_conditioner").put("sourceModelId",profile.getString("model"))
                .put("responseConfirmed",responseConfirmed).put("requestedState",PanasonicAcEncoder.defaults(profile).toJson());
            panasonicDraft=null;panasonicDraftDeviceId="";saveOrReplaceDevice(device,replacement);
        }catch(Exception error){message("Could not save the Panasonic remote: "+error.getMessage());}
    }
    private void recordedIrPage() {
        deviceHeading();
        JSONObject profile=infrared==null?null:infrared.find(selected.optString("profile"));
        if(profile==null) {
            card("Remote unavailable",infrared==null?"The Mi Remote catalogue is loading…":"Add this remote again from the Mi Remote catalogue.");
        }else {
            String category=profile.optString("category","tv");
            JSONObject commands=profile.optJSONObject("commands");
            if(commands==null)card("Signals",irProfileError.isEmpty()?"Loading this keyset’s recorded signals…":irProfileError);
            else {
                List<String> keys=new ArrayList<>();Iterator<String> names=commands.keys();while(names.hasNext())keys.add(names.next());
                Collections.sort(keys);RecordedControls controls=new RecordedControls(keys);
                String guidance="Aim the phone at your appliance. IR sent means the phone transmitted; confirm the appliance responds.";
                if(category.equals("air_conditioner"))guidance+=" Each captured setting may change several AC settings at once.";
                content.addView(text(guidance,12,MUTED,false));gap(content,12);
                recordedRow(controls,new String[]{"power","input"},new String[]{"Power","Input"},"power");
                boolean navigation=false;for(String role:new String[]{"up","down","left","right","ok"})if(controls.key(role)!=null)navigation=true;
                if(navigation) {
                    gap(content,10);LinearLayout pad=column();pad.setPadding(dp(12),dp(12),dp(12),dp(12));pad.setBackground(shape(CARD,32));
                    recordedPadRow(pad,controls,new String[]{null,"up",null},new String[]{"","▲",""});
                    recordedPadRow(pad,controls,new String[]{"left","ok","right"},new String[]{"◀","OK","▶"});
                    recordedPadRow(pad,controls,new String[]{null,"down",null},new String[]{"","▼",""});
                    content.addView(pad);gap(content,8);
                }
                recordedRow(controls,new String[]{"back","home","menu"},new String[]{"Back","Home","Menu"},"");
                if(controls.key("volume_up")!=null||controls.key("volume_down")!=null||controls.key("channel_up")!=null||controls.key("channel_down")!=null) {
                    gap(content,10);LinearLayout adjustments=row();
                    recordedRocker(adjustments,controls,"VOLUME","volume_up","volume_down");
                    recordedRocker(adjustments,controls,"CHANNEL","channel_up","channel_down");
                    content.addView(adjustments);
                }
                if(controls.key("temperature_up")!=null||controls.key("temperature_down")!=null) {
                    gap(content,10);content.addView(text("RECORDED TEMPERATURE CONTROLS",11,MUTED,true));gap(content,6);
                    recordedRow(controls,new String[]{"temperature_down","temperature_up"},new String[]{"Temperature −","Temperature +"},"");
                }
                recordedRow(controls,new String[]{"mute","guide","info"},new String[]{"Mute","Guide","Info"},"");
                recordedRow(controls,new String[]{"mode","fan_speed","timer"},new String[]{"Mode","Fan speed","Timer"},"");
                gap(content,12);
                if(!controls.digits().isEmpty()) {
                    full(content,action("123  Number pad",()->showRecordedCommands("Number pad",controls.digits(),commands),false),54);gap(content,8);
                }
                if(!controls.remaining.isEmpty()) {
                    full(content,action("More commands  ·  "+controls.remaining.size(),()->showRecordedCommands("More recorded commands",controls.remaining,commands),false),54);gap(content,8);
                }
                full(content,action("All recorded buttons  ·  "+keys.size(),()->showRecordedCommands("All recorded buttons",keys,commands),false),48);
                gap(content,14);content.addView(text("Source keyset: "+profile.optString("model",profile.optString("id")),11,MUTED,false));
                if(keys.isEmpty())card("No decoded buttons","This keyset has no available commands. Choose another matching keyset.");
            }
        }
        gap(content,14);full(content,action("Reload remote",this::connect,false),48);
        if(profile!=null) {
            gap(content,8);full(content,action("Find a working remote",()->retestIr(selected),false),48);
        }
        if(!notice.isEmpty()){gap(content,10);content.addView(text(notice,13,MUTED,false));}
        refreshButtons();
    }
    private Button recordedKey(String label,String sourceKey,boolean primary) {
        Button button=key(label,sourceKey,primary);
        button.setContentDescription(label+", recorded source key "+sourceKey);return button;
    }
    private void recordedRow(RecordedControls controls,String[] roles,String[] labels,String primary) {
        LinearLayout line=row();int count=0;
        for(int i=0;i<roles.length;i++) {
            String code=controls.key(roles[i]);if(code==null)continue;
            weighted(line,recordedKey(labels[i],code,roles[i].equals(primary)),58);count++;
        }
        if(count>0)content.addView(line);
    }
    private void recordedPadRow(LinearLayout pad,RecordedControls controls,String[] roles,String[] labels) {
        LinearLayout line=row();
        for(int i=0;i<roles.length;i++) {
            String code=roles[i]==null?null:controls.key(roles[i]);
            if(code==null)spacer(line);else weighted(line,recordedKey(labels[i],code,"ok".equals(roles[i])),64);
        }
        pad.addView(line);
    }
    private void recordedRocker(LinearLayout parent,RecordedControls controls,String heading,String plus,String minus) {
        if(controls.key(plus)==null&&controls.key(minus)==null)return;
        LinearLayout rocker=column();rocker.setGravity(Gravity.CENTER);rocker.setPadding(dp(8),dp(12),dp(8),dp(8));rocker.setBackground(shape(CARD,24));
        TextView title=text(heading,11,MUTED,true);title.setGravity(Gravity.CENTER);rocker.addView(title);gap(rocker,8);
        if(controls.key(plus)!=null){Button button=recordedKey("+",controls.key(plus),false);button.setContentDescription(heading.equals("VOLUME")?"Volume up":"Channel up");full(rocker,button,54);}
        gap(rocker,4);if(controls.key(minus)!=null){Button button=recordedKey("−",controls.key(minus),false);button.setContentDescription(heading.equals("VOLUME")?"Volume down":"Channel down");full(rocker,button,54);}
        weighted(parent,rocker,158);
    }
    private void showRecordedCommands(String title,List<String> codes,JSONObject commands) {
        LinearLayout body=column();body.setPadding(dp(16),0,dp(16),dp(12));
        TextView note=text("Only recorded source signals are shown. A transmission does not confirm an appliance response.",12,MUTED,false);body.addView(note);gap(body,10);
        ScrollView scroll=new ScrollView(this);LinearLayout grid=column();scroll.addView(grid);body.addView(scroll,new LinearLayout.LayoutParams(-1,dp(350)));
        List<View> transientButtons=new ArrayList<>();LinearLayout line=null;
        for(int i=0;i<codes.size();i++) {
            if(i%2==0){line=row();grid.addView(line);}
            String code=codes.get(i);JSONObject signal=commands.optJSONObject(code);
            String label=signal==null?code:signal.optString("label",code);
            Button button=recordedKey(label,code,false);button.setSingleLine(false);button.setPadding(dp(8),dp(10),dp(8),dp(10));
            LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(0,-2,1);params.setMargins(dp(3),dp(3),dp(3),dp(3));
            line.addView(button,params);transientButtons.add(button);
        }
        if(codes.size()%2==1)line.addView(new View(this),new LinearLayout.LayoutParams(0,1,1));
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(title).setView(body).setPositiveButton("Done",null).create();
        dialog.setOnDismissListener(d->{for(View button:transientButtons)commandButtons.remove(button);});dialog.show();refreshButtons();
    }
    private String commandLabel(JSONObject device,String command) {
        JSONObject profile=infrared==null?null:infrared.find(device.optString("profile"));
        JSONObject commands=profile==null?null:profile.optJSONObject("commands");
        JSONObject signal=commands==null?null:commands.optJSONObject(command);
        return signal==null?labelFor(command):signal.optString("label",command);
    }
    private void chooseMethod(String brand) { chooseMethod(brand,"tv"); }
    private void chooseMethod(String brand,String category) {
        if(!DemoScope.allowed(category,brand)){message("This brand is not included in Palm Remote Demo.");return;}
        if(category.equals("air_conditioner")){
            List<Choice> acOptions=new ArrayList<>();
            acOptions.add(new Choice("Find a working remote · Guided testing",()->acGuidedSetup(brand)));
            acOptions.add(new Choice("Browse AC controls and included data",()->irSetup(brand,category)));
            choices(brand+" connection",acOptions);return;
        }
        List<Choice> options=new ArrayList<>();
        if(infrared!=null&&!infrared.forBrand(brand,category).isEmpty()) {
            options.add(new Choice("Find a working remote · Guided testing",()->matchIrProfiles(brand,infrared.forBrand(brand,category))));
            options.add(new Choice("Browse recorded remotes",()->irSetup(brand,category)));
        }
        choices(brand+" connection",options);
    }
    private void acGuidedSetup(String brand) {
        if(infrared==null){message("The IR catalogue is unavailable.");return;}
        if((acSourceDatabase==null&&!acSourceFailed)||(panasonic==null&&!panasonicFailed)){
            message("AC candidates are loading. Try again shortly.");return;
        }
        AcGuidedCatalog guide=new AcGuidedCatalog(infrared,acSourceDatabase,panasonic,familyAc);
        List<JSONObject> recorded=guide.recorded(brand),settings=guide.settings(brand);
        int unavailable=guide.unavailableSourceCount(brand);
        if(recorded.isEmpty()&&settings.isEmpty()) {
            new AlertDialog.Builder(this).setTitle(brand+" · Guided testing unavailable")
                .setMessage("No sendable AC candidate is implemented for this brand. "+unavailable+" source definitions are included as data, but they still need an encoder. This app cannot test or save a working match from those definitions. No compatible signal is invented.")
                .setPositiveButton("Browse included data",(d,w)->browseAcSource(brand)).setNegativeButton("Close",null).show();return;
        }
        List<Choice> options=new ArrayList<>();
        for(JSONObject profile:settings) {
            String label=(profile.has("family")?"Experimental settings candidate":"Settings candidate")+" · "+profile.optString("model")+(profile.optBoolean("expanded")?" · "+profile.optString("family"):"");
            options.add(new Choice(label,()->panasonicSetup(null,profile.optString("id"),settings)));
        }
        if(!recorded.isEmpty())options.add(new Choice("Test recorded AC remotes · "+recorded.size()+" candidates",()->matchIrProfiles(brand,recorded)));
        if(acSourceDatabase!=null&&!acSourceDatabase.profiles(brand).isEmpty())
            options.add(new Choice("Browse included source data",()->browseAcSource(brand)));
        String note=guide.sendableCount(brand)+" sendable candidates: "+recorded.size()+" recorded remotes and "+settings.size()+" settings candidates. Aim at the AC and confirm its response before saving. Recorded signals may change several settings at once; settings tests request Cool 24 °C. "+unavailable+" additional source definitions have no encoder and cannot be tested. No appliance state is read.";
        choices(brand+" · AC guided testing",options,note);
    }
    private void irSetup(String brand,String category) {
        if(infrared==null){message("IR catalogue is unavailable.");return;}
        List<Choice> options=new ArrayList<>();
        List<JSONObject> profiles=infrared.forBrand(brand,category);
        if(category.equals("air_conditioner")&&acSourceDatabase!=null&&!acSourceDatabase.profiles(brand).isEmpty())
            options.add(new Choice("All included Mi APK AC profiles · "+acSourceDatabase.profiles(brand).size()+" source records",()->browseAcSource(brand)));
        if(brand.equalsIgnoreCase("Panasonic")&&category.equals("air_conditioner")) {
            options.add(new Choice("Find a Panasonic AC remote · Temperature and mode controls",this::panasonicSetup));
        }
        if(category.equals("air_conditioner")&&familyAc!=null)for(JSONObject candidate:familyAc.profiles())
            if(candidate.optString("brand").equalsIgnoreCase(brand))options.add(new Choice("Try experimental "+candidate.optString("family")+" controls · "+candidate.optString("model"),()->panasonicSetup(null,candidate.optString("id"))));
        if(!profiles.isEmpty())options.add(new Choice("Find a working remote · Guided testing",()->matchIrProfiles(brand,profiles)));
        for(int index=0;index<profiles.size();index++) {
            JSONObject profile=profiles.get(index);
            final int candidate=index;
            final String remoteName="Remote "+(index+1);
            String label=remoteName;
            if(profile.has("commandCount"))label+=" · "+profile.optInt("commandCount")+" recorded buttons";
            label+=" · "+profile.optString("model");
            options.add(new Choice(label,()->{
                if(!irHardware.hasEmitter) {
                    new AlertDialog.Builder(this).setTitle(irHardware.title)
                        .setMessage("You can save this Mi Remote keyset. IR sending stays disabled until a built-in emitter is detected. Tap Check IR above the page for phone hardware details. A matching appliance model is required.")
                        .setPositiveButton("Save anyway",(d,w)->saveIr(brand,profile,remoteName)).setNegativeButton("Cancel",null).show();
                }else matchIrProfiles(brand,profiles,candidate,null);
            }));
        }
        if(options.isEmpty()){message("No decoded Mi Remote keysets are available for this brand and category.");return;}
        choices(brand+" · Mi Remote keyset",options);
    }
    private void matchIrProfiles(String brand,List<JSONObject> profiles) {
        matchIrProfiles(brand,profiles,0,null);
    }
    private void retestIr(JSONObject device) {
        if(infrared==null||device==null)return;
        List<JSONObject> profiles=infrared.forBrand(device.optString("brand"),device.optString("category","tv"));
        // Re-testing starts with the source-prioritized candidates, including after an
        // older build saved the last candidate as its former "Remote 1".
        matchIrProfiles(device.optString("brand"),profiles,0,device);
    }
    private void matchIrProfiles(String brand,List<JSONObject> profiles,int startIndex,JSONObject replacement) {
        final IrCatalog catalogue=infrared;
        if(catalogue==null||profiles.isEmpty())return;
        final boolean television="tv".equals(profiles.get(0).optString("category"));
        final boolean decoder="set_top_box".equals(profiles.get(0).optString("category"));
        final boolean fan="fan".equals(profiles.get(0).optString("category"));
        final boolean airConditioner="air_conditioner".equals(profiles.get(0).optString("category"));
        final boolean confirmButtons=television||decoder||fan||airConditioner;
        final String appliance=airConditioner?"AC":fan?"fan":decoder?"decoder":"TV";
        final TvTestSession responses=new TvTestSession();
        LinearLayout body=column();body.setPadding(dp(20),dp(8),dp(20),dp(12));
        TextView position=text("",17,TEXT,true);body.addView(position);gap(body,8);
        TextView explanation=text(airConditioner?"Aim at the AC IR sensor. Each recorded signal may change several settings at once. Choose a recorded state, send it, and confirm the actual AC response before saving. Try Next remote if it does not respond. These captures do not read the AC state.":fan?"Aim the phone at the fan IR sensor and observe the fan. Try Power, Speed or Oscillation where recorded. Confirm two different buttons before saving, or the single available button on a limited candidate. If nothing happens, try the next remote.":decoder?"Turn the decoder and TV on. Aim the phone at the decoder IR sensor, not the TV. Try navigation, OK or channel buttons where available. Confirm two different buttons respond before saving. If nothing happens, try the next remote.":television?"Turn the TV on. Aim the phone at its IR sensor from 1–3 metres. Try Volume, Power, Input or navigation where available. Confirm two different buttons respond before saving. If nothing happens, try the next remote.":"Test one recorded button while aiming at the appliance. A keyset is a source capture, not a verified model match. Save only the remote you choose.",13,MUTED,false);
        body.addView(explanation);gap(body,12);
        Spinner command=new Spinner(this);body.addView(command,new LinearLayout.LayoutParams(-1,dp(52)));
        TextView result=text("Loading signals…",13,MUTED,false);result.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        gap(body,8);body.addView(result);gap(body,12);
        Button test=action("Send test signal",()->{},true);full(body,test,54);gap(body,12);
        Button responded=action(appliance+" responded to this button",()->{},false);
        responded.setEnabled(false);if(confirmButtons){full(body,responded,48);gap(body,8);}
        LinearLayout paging=row();Button previous=action("Previous",()->{},false),next=action("Next remote",()->{},false);
        weighted(paging,previous,48);weighted(paging,next,48);body.addView(paging);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(brand+" · Find your remote").setView(body)
            .setNegativeButton("Close",null).setPositiveButton("Use this remote",null).create();
        final int[] current={Math.max(0,Math.min(startIndex,profiles.size()-1))};final boolean[] sending={false},signalSent={false};
        final List<String> codes=new ArrayList<>();
        final java.util.concurrent.atomic.AtomicInteger request=new java.util.concurrent.atomic.AtomicInteger();
        final java.util.concurrent.atomic.AtomicBoolean active=new java.util.concurrent.atomic.AtomicBoolean(true);
        Runnable[] load=new Runnable[1];
        load[0]=()->{
            int token=request.incrementAndGet();JSONObject metadata=profiles.get(current[0]);signalSent[0]=false;responses.reset(airConditioner?1:fan?Math.min(2,metadata.optInt("commandCount",2)):2);responded.setEnabled(false);responded.setText(appliance+" responded to this button");
            position.setText("Remote "+(current[0]+1)+" of "+profiles.size()+" · "+metadata.optString("model")+(fan&&responses.requiredCount()==1?" · One recorded button only":""));
            result.setText("Loading recorded signals…");test.setEnabled(false);command.setEnabled(false);
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);
            previous.setEnabled(current[0]>0);next.setEnabled(current[0]<profiles.size()-1);codes.clear();
            worker.execute(()->{
                try {
                    if(!active.get()||token!=request.get())return;
                    JSONObject loaded=catalogue.loadProfile(metadata.optString("id"));
                    JSONObject signals=loaded.getJSONObject("commands");
                    List<String> found=new ArrayList<>();Iterator<String> keys=signals.keys();while(keys.hasNext())found.add(keys.next());Collections.sort(found);
                    List<String> labels=new ArrayList<>();for(String code:found)labels.add(signals.getJSONObject(code).optString("label",code)+" · "+code);
                    RecordedControls controls=new RecordedControls(found);String preferred=controls.key(decoder?"up":television?"volume_up":"power");if(preferred==null)preferred=controls.key("power");if(preferred==null)preferred=controls.key("mute");
                    final int initial=preferred==null?0:found.indexOf(preferred);
                    ui(()->{
                        if(!active.get()||token!=request.get())return;
                        codes.addAll(found);ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,labels);
                        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);command.setAdapter(adapter);
                        if(!codes.isEmpty())command.setSelection(initial);
                        command.setEnabled(!codes.isEmpty());test.setEnabled(irHardware.hasEmitter&&!codes.isEmpty());
                        result.setText(irHardware.hasEmitter?(airConditioner?"Choose a recorded state, send it, then tap AC responded only after observing the actual intended effect. A recorded signal can change several settings at once.":fan&&responses.requiredCount()==1?"Only one button is recorded for this candidate. Send it and confirm the fan responds. Saving confirms only that function, not a complete remote.":confirmButtons?"Step 1: send the selected recorded button, then confirm only if the "+appliance+" reacts. Choose and test a different button next.":"Choose a recorded button. Tap Send test signal, then check the appliance yourself."):irHardware.title+". You can browse here. To save without testing, choose a remote from the keyset list.");
                    });
                }catch(Exception error){ui(()->{if(active.get()&&token==request.get())result.setText("Could not load this keyset: "+error.getMessage());});}
            });
        };
        previous.setOnClickListener(v->{if(!sending[0]&&current[0]>0){current[0]--;load[0].run();}});
        next.setOnClickListener(v->{if(!sending[0]&&current[0]<profiles.size()-1){current[0]++;load[0].run();}});
        responded.setOnClickListener(v->{
            if(sending[0]||!responses.awaitingResponse()){return;}
            responses.confirm();responded.setEnabled(false);
            result.setText(responses.canSave()?(airConditioner?"AC response confirmed. Test more recorded states if needed, or tap Use this remote. Other settings may still need testing.":responses.requiredCount()==1?"The only recorded button is confirmed. This limited candidate controls only that recorded function. Tap Use this remote to save.":"Two different buttons confirmed. Test more buttons or tap Use this remote."):"One button confirmed. Choose a different button above, send it, and confirm the "+appliance+" responds.");
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(responses.canSave());
        });
        test.setOnClickListener(v->{
            if(sending[0]||!irHardware.hasEmitter||codes.isEmpty())return;
            int selection=command.getSelectedItemPosition();if(selection<0||selection>=codes.size())return;
            String sourceKey=codes.get(selection);JSONObject metadata=profiles.get(current[0]);int token=request.get();
            responses.sending();responded.setEnabled(false);
            sending[0]=true;test.setEnabled(false);previous.setEnabled(false);next.setEnabled(false);command.setEnabled(false);
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(false);result.setText("Sending one recorded signal…");
            worker.execute(()->{
                String outcome;boolean accepted=false;
                try {
                    if(destroyed||!active.get())return;
                    catalogue.transmit(metadata.optString("id"),sourceKey);
                    accepted=true;
                    outcome="IR sent. Did the appliance respond? Try another button to check, or choose the next remote. Palm cannot detect the response.";
                }catch(Exception error){outcome="Signal could not be sent: "+error.getMessage();}
                final String text=outcome;final boolean transmitted=accepted;ui(()->{
                    if(!active.get()||token!=request.get())return;
                    sending[0]=false;signalSent[0]|=transmitted;result.setText(text);test.setEnabled(irHardware.hasEmitter);command.setEnabled(true);
                    previous.setEnabled(current[0]>0);next.setEnabled(current[0]<profiles.size()-1);
                    if(confirmButtons&&transmitted){
                        responses.sent(sourceKey);responded.setEnabled(true);
                        responded.setText(appliance+" responded · "+sourceKey);
                        result.setText("Sent "+sourceKey+". Did the "+appliance+" react correctly? Confirm below, or try another button / Next remote. Confirmed buttons: "+responses.count()+"/"+responses.requiredCount()+". Palm cannot detect the "+appliance+" response.");
                    }
                    if(confirmButtons&&current[0]==profiles.size()-1)
                        result.append(" Last candidate. If none responds, check the phone emitter, aim and "+appliance+" model; this catalogue may not cover your "+appliance+".");
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(confirmButtons?responses.canSave():signalSent[0]);
                });
            });
        });
        dialog.setOnDismissListener(d->{
            active.set(false);request.incrementAndGet();
            // Browsing keysets shares the bounded cache with the selected remote. Restore it
            // after queued wizard reads finish; connect() retains the device-generation guard.
            final JSONObject originalSelection=selected;
            if(!destroyed)worker.execute(()->ui(()->{
                if(catalogue==infrared&&selected==originalSelection&&selectedUsesIr()&&!catalogue.isLoaded(selected.optString("profile")))connect();
            }));
        });
        dialog.setOnShowListener(d->{
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
                if(sending[0]||!(confirmButtons?responses.canSave():signalSent[0]))return;JSONObject chosen=profiles.get(current[0]);String name="Remote "+(current[0]+1);
                new AlertDialog.Builder(this).setTitle("Did your appliance respond?")
                    .setMessage(fan&&chosen.optInt("commandCount")==1?"This candidate has only one recorded button. Save only if that function worked. This does not provide missing power, speed or oscillation controls. Palm cannot detect the response.":"Save this keyset only if the appliance responded correctly to your test. Palm cannot detect that response. Other buttons may still need testing.")
                    .setNegativeButton("Keep testing",null).setPositiveButton("Yes, save remote",(confirm,which)->{dialog.dismiss();saveIr(brand,chosen,name,true,replacement);}).show();
            });load[0].run();
        });dialog.show();
    }
    private void saveIr(String brand,JSONObject profile,String remoteName) {
        saveIr(brand,profile,remoteName,false,null);
    }
    private void saveIr(String brand,JSONObject profile,String remoteName,boolean responseConfirmed,JSONObject replacement) {
        try {
            JSONObject device=replacement==null?baseDevice(brand,"ir",brand+" · "+remoteName):new JSONObject(replacement.toString());
            device.put("name",brand+" · "+remoteName).put("brand",brand).put("mode","ir").put("responseConfirmed",responseConfirmed);
            device.put("profile",profile.getString("id"));device.put("category",profile.optString("category","tv"));
            JSONObject source=profile.optJSONObject("source");if(source!=null)device.put("sourceModelId",source.optString("modelId"));
            saveOrReplaceDevice(device,replacement);
        }catch(Exception e){message(e.getMessage());}
    }
    private JSONObject baseDevice(String brand,String mode,String name)throws Exception {
        return new JSONObject().put("id",UUID.randomUUID().toString()).put("brand",brand).put("mode",mode).put("name",name).put("category","tv");
    }
    private void saveDevice(JSONObject device) {devices.add(device);store.save(devices);select(device);}
    private void saveOrReplaceDevice(JSONObject device,JSONObject replacement) {
        if(replacement==null){saveDevice(device);return;}
        for(int i=0;i<devices.size();i++)if(devices.get(i).optString("id").equals(replacement.optString("id"))){devices.set(i,device);store.save(devices);select(device);return;}
        // The original entry may have been removed while the wizard was open.
        saveDevice(device);
    }
    private void select(JSONObject device) {selected=device;currentPage="Remote";status="Connecting…";notice="";render();connect();}
    private void pickDevice() {
        if(devices.isEmpty()){addBrand();return;}
        String[] names=new String[devices.size()+1];for(int i=0;i<devices.size();i++)names[i]=devices.get(i).optString("name");names[devices.size()]="+ Add a remote";
        new AlertDialog.Builder(this).setTitle("Choose your remote").setItems(names,(d,i)->{if(i==devices.size())addBrand();else select(devices.get(i));}).show();
    }
    private EditText input(String hint,boolean secret) {
        EditText field=new EditText(this);field.setHint(hint);field.setSingleLine();field.setTextColor(TEXT);field.setHintTextColor(MUTED);
        field.setInputType(secret?InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD:InputType.TYPE_CLASS_TEXT);
        field.setPadding(dp(12),dp(10),dp(12),dp(10));
        if(secret && android.os.Build.VERSION.SDK_INT>=26)field.setImportantForAutofill(View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS);
        return field;
    }
    private void keypad() {
        if(cloud!=null && cloudDevice!=null) {
            if(!cloudDevice.getCapabilities().contains("tvChannel")){message("This TV does not publish channel selection.");return;}
            EditText channel=input("Channel number, e.g. 101",false);
            channel.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
            final SmartThingsClient client=cloud;final SmartThingsClient.Device device=cloudDevice;
            new AlertDialog.Builder(this).setTitle("Choose a channel").setView(channel)
                .setNegativeButton("Cancel",null).setPositiveButton("Tune",(d,w)->runCloudAction(()->client.setChannel(device,channel.getText().toString().trim()))).show();
            return;
        }
        LinearLayout pad=column();pad.setPadding(dp(14),dp(10),dp(14),dp(10));
        for(int r=0;r<3;r++){LinearLayout line=row();for(int c=1;c<=3;c++){String n=String.valueOf(r*3+c);command(line,n,"digit_"+n,false);}pad.addView(line);}
        LinearLayout line=row();spacer(line);command(line,"0","digit_0",false);spacer(line);pad.addView(line);
        new AlertDialog.Builder(this).setTitle("Number pad").setView(pad).setPositiveButton("Done",null).show();refreshButtons();
    }
    private interface CloudAction {void execute() throws Exception;}
    private void runCloudAction(CloudAction action) {
        if(busy||!connected)return;
        busy=true;refreshButtons();final long generation=connectionGeneration;
        worker.execute(()->{
            try{action.execute();ui(()->{if(generation==connectionGeneration)updateStatus("SmartThings command accepted",true);});}
            catch(Exception e){ui(()->{if(generation==connectionGeneration)message(e.getMessage());});}
            finally{ui(()->{if(generation==connectionGeneration){busy=false;refreshButtons();}});}
        });
    }
    private void cloudInput() {
        final SmartThingsClient client=cloud;final SmartThingsClient.Device device=cloudDevice;
        final long generation=connectionGeneration;busy=true;refreshButtons();
        worker.execute(()->{
            try{
                List<String> inputs=client.inputSources(device);
                ui(()->{
                    if(generation!=connectionGeneration)return;
                    if(inputs.isEmpty()){message("No input sources were published by this TV.");return;}
                    new AlertDialog.Builder(this).setTitle("TV input").setItems(inputs.toArray(new String[0]),
                        (d,index)->{if(generation==connectionGeneration)runCloudAction(()->client.setInputSource(device,inputs.get(index)));}).setNegativeButton("Cancel",null).show();
                });
            }catch(Exception e){ui(()->{if(generation==connectionGeneration)message(e.getMessage());});}
            finally{ui(()->{if(generation==connectionGeneration){busy=false;refreshButtons();}});}
        });
    }
    private void message(String value) {Toast.makeText(this,value==null?"Connection failed":value,Toast.LENGTH_LONG).show();}
    private void ui(Runnable task) {if(!destroyed)runOnUiThread(()->{if(!destroyed)task.run();});}
    @Override protected void onDestroy(){destroyed=true;connectionGeneration++;if(network!=null)network.dispose();worker.shutdownNow();hardwareWorker.shutdownNow();acSourceWorker.shutdownNow();super.onDestroy();}
}

